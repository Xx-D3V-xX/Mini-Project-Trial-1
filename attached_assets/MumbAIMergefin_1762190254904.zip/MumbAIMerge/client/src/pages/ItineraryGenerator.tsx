import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { generateItinerarySchema, type GenerateItineraryInput, type Itinerary } from "@shared/schema";
import { Sparkles, MapPin, Clock, Check, Loader2, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";

const INTERESTS = [
  "Food & Cuisine",
  "Heritage & History",
  "Nature & Parks",
  "Shopping & Markets",
  "Art & Culture",
  "Adventure",
  "Photography",
  "Local Life",
];

const TRAVEL_MODES = [
  { value: "Walking", label: "Walking", icon: "🚶" },
  { value: "Public Transport", label: "Public Transport", icon: "🚌" },
  { value: "Private Car", label: "Private Car", icon: "🚗" },
] as const;

export default function ItineraryGenerator() {
  const [generatedItinerary, setGeneratedItinerary] = useState<Itinerary | null>(null);
  const { toast } = useToast();

  const form = useForm<GenerateItineraryInput>({
    resolver: zodResolver(generateItinerarySchema),
    defaultValues: {
      days: 2,
      interests: [],
      budget: "Moderate",
      travelMode: "Public Transport",
    },
  });

  const generateMutation = useMutation({
    mutationFn: async (data: GenerateItineraryInput) => {
      const response = await apiRequest<Itinerary>("POST", "/api/itinerary/generate", data);
      return response;
    },
    onSuccess: (data) => {
      setGeneratedItinerary(data);
      toast({
        title: "Itinerary generated!",
        description: "Your personalized Mumbai itinerary is ready",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Generation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (itinerary: Itinerary) => {
      return apiRequest("POST", "/api/profile/itineraries", itinerary);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile/itineraries"] });
      toast({
        title: "Itinerary saved!",
        description: "Added to your profile",
      });
    },
  });

  const handleGenerate = (data: GenerateItineraryInput) => {
    generateMutation.mutate(data);
  };

  const handleSave = () => {
    if (generatedItinerary) {
      saveMutation.mutate(generatedItinerary);
    }
  };

  const selectedInterests = form.watch("interests");
  const budgetValue = form.watch("budget");
  const travelMode = form.watch("travelMode");
  const daysValue = form.watch("days");

  const budgetLabels = {
    Budget: "Budget-Friendly",
    Moderate: "Moderate",
    Luxury: "Premium Experience",
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-serif text-4xl md:text-5xl font-bold mb-3 flex items-center gap-3" data-testid="text-page-title">
            <Sparkles className="w-10 h-10 text-primary" />
            AI Itinerary Generator
          </h1>
          <p className="text-lg text-muted-foreground">
            Let AI create a personalized Mumbai itinerary based on your preferences
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Form Section */}
          <div className="lg:col-span-2">
            <Card className="p-6 sticky top-20">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleGenerate)} className="space-y-6">
                  {/* Days */}
                  <FormField
                    control={form.control}
                    name="days"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How many days?</FormLabel>
                        <div className="flex items-center gap-4">
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            onClick={() => field.onChange(Math.max(1, field.value - 1))}
                            disabled={field.value <= 1}
                            data-testid="button-decrease-days"
                          >
                            -
                          </Button>
                          <div className="flex-1 text-center">
                            <span className="text-3xl font-bold" data-testid="text-days-value">
                              {field.value}
                            </span>
                            <span className="text-muted-foreground ml-2">
                              day{field.value > 1 ? "s" : ""}
                            </span>
                          </div>
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            onClick={() => field.onChange(Math.min(7, field.value + 1))}
                            disabled={field.value >= 7}
                            data-testid="button-increase-days"
                          >
                            +
                          </Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Interests */}
                  <FormField
                    control={form.control}
                    name="interests"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>What interests you?</FormLabel>
                        <FormDescription>Select at least one interest</FormDescription>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {INTERESTS.map((interest) => {
                            const isSelected = field.value.includes(interest);
                            return (
                              <Badge
                                key={interest}
                                variant={isSelected ? "default" : "outline"}
                                className="cursor-pointer hover-elevate active-elevate-2 px-3 py-1.5"
                                onClick={() => {
                                  const newValue = isSelected
                                    ? field.value.filter((i) => i !== interest)
                                    : [...field.value, interest];
                                  field.onChange(newValue);
                                }}
                                data-testid={`badge-interest-${interest.replace(/\s+/g, "-").toLowerCase()}`}
                              >
                                {isSelected && <Check className="w-3 h-3 mr-1" />}
                                {interest}
                              </Badge>
                            );
                          })}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Budget */}
                  <FormField
                    control={form.control}
                    name="budget"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Budget Level</FormLabel>
                        <div className="space-y-4">
                          <div className="text-center py-3 px-4 bg-muted rounded-lg">
                            <span className="font-semibold" data-testid="text-budget-value">
                              {budgetLabels[field.value]}
                            </span>
                          </div>
                          <div className="grid grid-cols-3 gap-2">
                            {(["Budget", "Moderate", "Luxury"] as const).map((level) => (
                              <Button
                                key={level}
                                type="button"
                                variant={field.value === level ? "default" : "outline"}
                                onClick={() => field.onChange(level)}
                                data-testid={`button-budget-${level.toLowerCase()}`}
                              >
                                {level}
                              </Button>
                            ))}
                          </div>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Travel Mode */}
                  <FormField
                    control={form.control}
                    name="travelMode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Travel Mode</FormLabel>
                        <div className="grid grid-cols-1 gap-2">
                          {TRAVEL_MODES.map((mode) => (
                            <Button
                              key={mode.value}
                              type="button"
                              variant={field.value === mode.value ? "default" : "outline"}
                              className="justify-start gap-2"
                              onClick={() => field.onChange(mode.value)}
                              data-testid={`button-mode-${mode.value.replace(/\s+/g, "-").toLowerCase()}`}
                            >
                              <span className="text-xl">{mode.icon}</span>
                              {mode.label}
                              {field.value === mode.value && <Check className="w-4 h-4 ml-auto" />}
                            </Button>
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full"
                    size="lg"
                    disabled={generateMutation.isPending || selectedInterests.length === 0}
                    data-testid="button-generate"
                  >
                    {generateMutation.isPending ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Generate Itinerary
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </Card>
          </div>

          {/* Preview Section */}
          <div className="lg:col-span-3">
            {generateMutation.isPending ? (
              <div className="space-y-4">
                <Card className="p-6">
                  <Skeleton className="h-8 w-3/4 mb-4" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-2/3" />
                </Card>
                {Array.from({ length: daysValue }).map((_, i) => (
                  <Card key={i} className="p-6">
                    <Skeleton className="h-6 w-32 mb-4" />
                    <div className="space-y-3">
                      {Array.from({ length: 3 }).map((_, j) => (
                        <div key={j} className="flex gap-3">
                          <Skeleton className="w-20 h-20 rounded-lg flex-shrink-0" />
                          <div className="flex-1 space-y-2">
                            <Skeleton className="h-5 w-3/4" />
                            <Skeleton className="h-4 w-full" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </Card>
                ))}
              </div>
            ) : generatedItinerary ? (
              <div className="space-y-6">
                <Card className="p-6">
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-4">
                    <div>
                      <h2 className="font-serif text-3xl font-bold mb-2" data-testid="text-itinerary-title">
                        {generatedItinerary.title}
                      </h2>
                      <p className="text-muted-foreground" data-testid="text-itinerary-summary">
                        {generatedItinerary.summary}
                      </p>
                    </div>
                    <Button onClick={handleSave} disabled={saveMutation.isPending} data-testid="button-save">
                      <Save className="w-4 h-4 mr-2" />
                      {saveMutation.isPending ? "Saving..." : "Save Itinerary"}
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Badge>{generatedItinerary.days} Days</Badge>
                    <Badge variant="secondary">{generatedItinerary.budget}</Badge>
                    <Badge variant="secondary">{generatedItinerary.travelMode}</Badge>
                    {generatedItinerary.interests?.map((interest, i) => (
                      <Badge key={i} variant="outline">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </Card>

                {generatedItinerary.dailyPlan?.map((day) => (
                  <Card key={day.day} className="p-6" data-testid={`card-day-${day.day}`}>
                    <h3 className="font-serif text-2xl font-bold mb-4 flex items-center gap-2">
                      <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm">
                        {day.day}
                      </span>
                      Day {day.day}
                    </h3>
                    <div className="space-y-4">
                      {day.pois.map((poi, index) => (
                        <div key={index} className="flex gap-4 p-4 rounded-lg hover-elevate" data-testid={`poi-${day.day}-${index}`}>
                          {poi.imageUrl && (
                            <div className="w-24 h-24 rounded-lg overflow-hidden flex-shrink-0">
                              <img
                                src={poi.imageUrl}
                                alt={poi.name}
                                className="w-full h-full object-cover"
                                loading="lazy"
                              />
                            </div>
                          )}
                          <div className="flex-1">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <h4 className="font-semibold text-lg" data-testid={`poi-name-${day.day}-${index}`}>
                                {poi.name}
                              </h4>
                              <Badge variant="outline" data-testid={`poi-time-${day.day}-${index}`}>
                                <Clock className="w-3 h-3 mr-1" />
                                {poi.time}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground flex items-start gap-1 mb-2">
                              <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                              <span data-testid={`poi-address-${day.day}-${index}`}>{poi.address}</span>
                            </p>
                            {poi.notes && (
                              <p className="text-sm text-muted-foreground" data-testid={`poi-notes-${day.day}-${index}`}>
                                {poi.notes}
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                  <Sparkles className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-serif text-2xl font-bold mb-3">
                  Ready to Plan Your Mumbai Adventure?
                </h3>
                <p className="text-muted-foreground max-w-md mx-auto mb-6">
                  Fill in your preferences and let our AI create a personalized itinerary tailored just for you
                </p>
                <div className="flex flex-wrap gap-2 justify-center">
                  <Badge variant="outline">Personalized Routes</Badge>
                  <Badge variant="outline">Local Recommendations</Badge>
                  <Badge variant="outline">Time-Optimized</Badge>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
