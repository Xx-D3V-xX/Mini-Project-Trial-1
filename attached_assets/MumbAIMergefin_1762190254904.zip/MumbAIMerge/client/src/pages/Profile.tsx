import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { LoadingState } from "@/components/LoadingState";
import { EmptyState } from "@/components/EmptyState";
import {
  MapPin,
  Calendar,
  Star,
  Download,
  Trash2,
  Eye,
  Sparkles,
} from "lucide-react";
import { Link } from "wouter";
import type { Itinerary, TravelHistory, User } from "@shared/schema";
import { format } from "date-fns";

export default function Profile() {
  const { data: user, isLoading: userLoading } = useQuery<User>({
    queryKey: ["/api/profile"],
  });

  const { data: itineraries, isLoading: itinerariesLoading } = useQuery<Itinerary[]>({
    queryKey: ["/api/profile/itineraries"],
  });

  const { data: history, isLoading: historyLoading } = useQuery<TravelHistory[]>({
    queryKey: ["/api/profile/history"],
  });

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  if (userLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <LoadingState />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <Card className="p-6 md:p-8 mb-8">
          <div className="flex flex-col md:flex-row gap-6">
            <Avatar className="w-24 h-24">
              <AvatarImage src={user.avatarUrl || undefined} alt={user.name} />
              <AvatarFallback className="text-2xl">{getInitials(user.name)}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-4">
                <div>
                  <h1 className="font-serif text-3xl font-bold mb-1" data-testid="text-user-name">
                    {user.name}
                  </h1>
                  <p className="text-muted-foreground" data-testid="text-user-email">
                    {user.email}
                  </p>
                </div>
                <Button variant="outline" data-testid="button-edit-profile">
                  Edit Profile
                </Button>
              </div>
              {user.interests && user.interests.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {user.interests.map((interest, index) => (
                    <Badge key={index} variant="secondary" data-testid={`badge-interest-${index}`}>
                      {interest}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary" data-testid="text-stat-itineraries">
                {itineraries?.length || 0}
              </div>
              <div className="text-sm text-muted-foreground">Itineraries</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary" data-testid="text-stat-history">
                {history?.length || 0}
              </div>
              <div className="text-sm text-muted-foreground">Places Visited</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary" data-testid="text-stat-trails">
                {Math.floor((history?.length || 0) / 3)}
              </div>
              <div className="text-sm text-muted-foreground">Trails Completed</div>
            </div>
          </div>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="itineraries" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="itineraries" data-testid="tab-itineraries">
              My Itineraries
            </TabsTrigger>
            <TabsTrigger value="history" data-testid="tab-history">
              Travel History
            </TabsTrigger>
          </TabsList>

          {/* My Itineraries Tab */}
          <TabsContent value="itineraries" className="space-y-4">
            {itinerariesLoading ? (
              <LoadingState />
            ) : itineraries && itineraries.length > 0 ? (
              <div className="space-y-4">
                {itineraries.map((itinerary) => (
                  <Card key={itinerary.id} className="p-6 hover-elevate" data-testid={`card-itinerary-${itinerary.id}`}>
                    <div className="flex flex-col md:flex-row gap-6">
                      {/* Thumbnail Grid */}
                      <div className="grid grid-cols-2 gap-2 w-full md:w-48 h-32 rounded-lg overflow-hidden flex-shrink-0">
                        {itinerary.dailyPlan?.slice(0, 1).map((day) =>
                          day.pois.slice(0, 4).map((poi, index) => (
                            <div key={index} className="aspect-square bg-muted">
                              {poi.imageUrl && (
                                <img
                                  src={poi.imageUrl}
                                  alt={poi.name}
                                  className="w-full h-full object-cover"
                                  loading="lazy"
                                />
                              )}
                            </div>
                          ))
                        )}
                      </div>

                      {/* Details */}
                      <div className="flex-1">
                        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-2 mb-3">
                          <div>
                            <h3 className="font-serif text-xl font-bold mb-1" data-testid={`text-itinerary-title-${itinerary.id}`}>
                              {itinerary.title}
                            </h3>
                            {itinerary.createdAt && (
                              <p className="text-sm text-muted-foreground flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                Created {format(new Date(itinerary.createdAt), "MMM d, yyyy")}
                              </p>
                            )}
                          </div>
                          <Badge data-testid={`badge-days-${itinerary.id}`}>
                            {itinerary.days} Day{itinerary.days > 1 ? "s" : ""}
                          </Badge>
                        </div>
                        <p className="text-muted-foreground mb-4 line-clamp-2">
                          {itinerary.summary || "Your personalized Mumbai itinerary"}
                        </p>
                        <div className="flex flex-wrap gap-2">
                          <Button size="sm" variant="outline" data-testid={`button-view-${itinerary.id}`}>
                            <Eye className="w-4 h-4 mr-1" />
                            View
                          </Button>
                          <Button size="sm" variant="outline" data-testid={`button-download-${itinerary.id}`}>
                            <Download className="w-4 h-4 mr-1" />
                            Export
                          </Button>
                          <Button size="sm" variant="outline" data-testid={`button-delete-${itinerary.id}`}>
                            <Trash2 className="w-4 h-4 mr-1" />
                            Delete
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <EmptyState
                title="No itineraries yet"
                description="Start planning your Mumbai adventure with our AI-powered itinerary generator"
                actionLabel="Generate Itinerary"
                onAction={() => window.location.href = "/itinerary/generate"}
                icon="sparkles"
              />
            )}
          </TabsContent>

          {/* Travel History Tab */}
          <TabsContent value="history" className="space-y-4">
            {historyLoading ? (
              <LoadingState />
            ) : history && history.length > 0 ? (
              <div className="space-y-4">
                {history.map((visit) => (
                  <Card key={visit.id} className="p-6 hover-elevate" data-testid={`card-history-${visit.id}`}>
                    <div className="flex flex-col md:flex-row gap-6">
                      {visit.imageUrl && (
                        <div className="w-full md:w-32 h-32 rounded-lg overflow-hidden flex-shrink-0">
                          <img
                            src={visit.imageUrl}
                            alt={visit.placeName}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                        </div>
                      )}
                      <div className="flex-1">
                        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-2 mb-2">
                          <div>
                            <h3 className="font-serif text-xl font-bold mb-1" data-testid={`text-place-${visit.id}`}>
                              {visit.placeName}
                            </h3>
                            <p className="text-sm text-muted-foreground flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              Visited {format(new Date(visit.visitDate), "MMM d, yyyy")}
                            </p>
                          </div>
                          <div className="flex items-center gap-1" data-testid={`rating-${visit.id}`}>
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`w-4 h-4 ${
                                  i < visit.rating
                                    ? "fill-accent text-accent"
                                    : "text-muted"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        {visit.notes && (
                          <p className="text-muted-foreground mb-2" data-testid={`notes-${visit.id}`}>
                            {visit.notes}
                          </p>
                        )}
                        {visit.bookingId && (
                          <p className="text-xs text-muted-foreground">
                            Booking ID: {visit.bookingId}
                          </p>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <EmptyState
                title="No travel history"
                description="Start exploring Mumbai trails and your visits will appear here"
                actionLabel="Explore Trails"
                onAction={() => window.location.href = "/explore"}
                icon="map"
              />
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
