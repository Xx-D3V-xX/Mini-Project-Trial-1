import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, Filter } from "lucide-react";
import { TrailCard } from "@/components/TrailCard";
import { LoadingState } from "@/components/LoadingState";
import { EmptyState } from "@/components/EmptyState";
import type { Trail } from "@shared/schema";

export default function Explore() {
  const [searchQuery, setSearchQuery] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [difficulty, setDifficulty] = useState<string>("all");

  const { data: trails, isLoading } = useQuery<Trail[]>({
    queryKey: ["/api/trails"],
  });

  const filteredTrails = trails?.filter((trail) => {
    const matchesSearch = trail.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         trail.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = category === "all" || trail.category === category;
    const matchesDifficulty = difficulty === "all" || trail.difficulty === difficulty;
    
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="font-serif text-4xl md:text-5xl font-bold mb-3" data-testid="text-page-title">
            Explore Mumbai Trails
          </h1>
          <p className="text-lg text-muted-foreground">
            Discover curated walking experiences across food, heritage, and nature
          </p>
        </div>

        {/* Search and Filters */}
        <div className="sticky top-16 z-40 bg-background/95 backdrop-blur-sm border-b pb-6 mb-8 -mx-4 px-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search trails..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search"
              />
            </div>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-full md:w-[180px]" data-testid="select-category">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Food">Food</SelectItem>
                <SelectItem value="Heritage">Heritage</SelectItem>
                <SelectItem value="Nature">Nature</SelectItem>
                <SelectItem value="Shopping">Shopping</SelectItem>
                <SelectItem value="Adventure">Adventure</SelectItem>
              </SelectContent>
            </Select>
            <Select value={difficulty} onValueChange={setDifficulty}>
              <SelectTrigger className="w-full md:w-[180px]" data-testid="select-difficulty">
                <SelectValue placeholder="Difficulty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="Easy">Easy</SelectItem>
                <SelectItem value="Moderate">Moderate</SelectItem>
                <SelectItem value="Challenging">Challenging</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Results */}
        {isLoading ? (
          <LoadingState />
        ) : filteredTrails && filteredTrails.length > 0 ? (
          <>
            <div className="mb-4 text-sm text-muted-foreground" data-testid="text-results-count">
              {filteredTrails.length} trail{filteredTrails.length !== 1 ? "s" : ""} found
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTrails.map((trail) => (
                <TrailCard key={trail.id} trail={trail} />
              ))}
            </div>
          </>
        ) : (
          <EmptyState
            title="No trails found"
            description="Try adjusting your search or filters to discover more trails"
            icon="map"
          />
        )}
      </div>
    </div>
  );
}
