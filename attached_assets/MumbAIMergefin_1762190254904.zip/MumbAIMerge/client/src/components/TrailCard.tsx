import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Clock, Star } from "lucide-react";
import { useState } from "react";
import type { Trail } from "@shared/schema";

const FALLBACK_IMAGE = "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=800&h=600&fit=crop";

interface TrailCardProps {
  trail: Trail;
  onClick?: () => void;
}

export function TrailCard({ trail, onClick }: TrailCardProps) {
  const [imgSrc, setImgSrc] = useState(trail.imageUrl || FALLBACK_IMAGE);

  const handleImageError = () => {
    setImgSrc(FALLBACK_IMAGE);
  };

  return (
    <Card 
      className="overflow-hidden hover-elevate active-elevate-2 cursor-pointer transition-all group"
      onClick={onClick}
      data-testid={`card-trail-${trail.id}`}
    >
      <div className="relative aspect-[16/9] overflow-hidden">
        <img
          src={imgSrc}
          alt={trail.title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          onError={handleImageError}
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        <Badge 
          className="absolute top-3 left-3 bg-card/90 backdrop-blur-sm border-card-border text-card-foreground"
          data-testid={`badge-category-${trail.category}`}
        >
          {trail.category}
        </Badge>
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h3 className="font-serif text-xl font-bold text-white mb-1" data-testid={`text-trail-title-${trail.id}`}>
            {trail.title}
          </h3>
        </div>
      </div>
      <div className="p-4 space-y-3">
        <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`text-trail-description-${trail.id}`}>
          {trail.description}
        </p>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1" data-testid={`text-duration-${trail.id}`}>
              <Clock className="w-4 h-4" />
              <span>{trail.duration}</span>
            </div>
            <div className="flex items-center gap-1" data-testid={`text-rating-${trail.id}`}>
              <Star className="w-4 h-4 fill-accent text-accent" />
              <span>{trail.rating}/5</span>
            </div>
          </div>
          <Badge variant="secondary" data-testid={`badge-difficulty-${trail.difficulty}`}>
            {trail.difficulty}
          </Badge>
        </div>
        <Button 
          className="w-full" 
          variant="outline"
          data-testid={`button-view-trail-${trail.id}`}
        >
          View Details
        </Button>
      </div>
    </Card>
  );
}
