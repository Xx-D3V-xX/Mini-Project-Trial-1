# MumbAI Trails Design Guidelines

## Design Approach

**Selected Approach:** Reference-Based (Travel/Discovery Platform)  
**Primary References:** Airbnb (card aesthetics, imagery focus), Google Travel (itinerary planning), TripAdvisor (reviews and history)

**Core Design Principles:**
- Visual discovery through rich imagery
- Effortless itinerary creation and management
- Trust-building through user history and social proof
- Mobile-first responsive design for on-the-go travelers

---

## Typography System

**Font Stack:**
- Primary: 'Inter' or 'DM Sans' via Google Fonts CDN
- Accent: 'Playfair Display' for hero headlines and section titles (heritage feel)

**Hierarchy:**
- Hero Headlines: 3.5rem (desktop) / 2.5rem (mobile), accent font, bold
- Page Titles: 2.5rem / 1.875rem, primary font, semibold
- Section Headers: 1.875rem / 1.5rem, primary font, semibold
- Card Titles: 1.25rem, primary font, medium
- Body Text: 1rem, primary font, regular
- Captions/Meta: 0.875rem, primary font, regular

---

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24 (p-2, m-4, space-y-6, gap-8, etc.)

**Container Strategy:**
- Full-width sections: `w-full` with inner `max-w-7xl mx-auto px-4 md:px-8`
- Content sections: `max-w-6xl mx-auto`
- Form containers: `max-w-2xl mx-auto`
- Card grids: `grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6`

**Vertical Rhythm:**
- Section padding: `py-12 md:py-20` for landing sections
- Component spacing: `space-y-8` between major elements
- Card padding: `p-4 md:p-6`

---

## Landing Page (/) Structure

### Hero Section (80vh on desktop, natural height mobile)
- **Layout:** Full-width background image with centered content overlay
- **Content:** Large headline, subheading, dual CTAs (primary: "Explore Mumbai Trails", secondary: "Login" or "Go to Explore" if authenticated)
- **Buttons:** Blurred background treatment for readability over images
- **Composition:** Single-column centered layout, max-w-3xl for text content

### Featured Trails Section
- **Layout:** 3-column grid on desktop (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)
- **Cards:** Image-first design with 16:9 aspect ratio, title overlay on image bottom with gradient backdrop
- **Supporting Elements:** Category badges, duration indicators, difficulty level icons
- **Spacing:** gap-6 between cards, py-20 section padding

### How It Works Section
- **Layout:** 3-column feature grid with icons
- **Components:** Icon (from Heroicons), heading, description
- **Flow:** "Discover Trails" → "Plan Itinerary" → "Explore Mumbai"
- **Enhancement:** Subtle step numbers, connecting visual elements between steps

### Social Proof Section
- **Layout:** 2-column grid for testimonials (grid-cols-1 md:grid-cols-2)
- **Components:** User avatar, name, rating stars, testimonial text, location visited
- **Additional:** Stats row above testimonials (e.g., "10,000+ Trails Explored", "500+ Heritage Sites")

### Call-to-Action Section
- **Layout:** Centered single-column with background image
- **Content:** Compelling headline, button, supporting text about app benefits
- **Spacing:** py-24 for prominence

### Footer
- **Layout:** 4-column grid (About, Quick Links, Popular Trails, Newsletter)
- **Components:** Logo, navigation links, social icons, newsletter signup form, contact info, trust badges
- **Enhancement:** Mumbai skyline illustration or pattern element

---

## Explore Page (/explore)

**Layout Pattern:** Search and filter bar at top, followed by masonry/grid of trail cards

### Search & Filter Bar
- **Position:** Sticky top with backdrop blur
- **Components:** Search input with icon, filter dropdowns (Category, Duration, Difficulty), sort selector
- **Layout:** Horizontal flex layout with responsive stacking on mobile

### Trail Cards Grid
- **Layout:** grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
- **Card Structure:**
  - Image: 16:9 aspect ratio with hover zoom effect
  - Content overlay: Title, location icon + text, category badge
  - Below image: Quick stats row (duration, stops, rating), "View Details" link
- **Image Handling:** All images with fallback onError handler, placeholder: unsplash/featured/?mumbai,heritage

---

## Profile Page (/profile)

**Header Section:**
- **Layout:** 2-column split (avatar/info left, stats right)
- **Left:** Large avatar, name, email, "Edit Profile" button, interests badges
- **Right:** Stats cards (Trails Completed, Places Visited, Itineraries Saved)
- **Spacing:** py-12 section padding

**Tabs Navigation:**
- **Style:** Horizontal pills/underline tabs, sticky below header
- **Options:** "My Itineraries" (active), "Travel History"

### My Itineraries Tab
- **Layout:** List view with alternating card layout
- **Card Structure:**
  - Left: Thumbnail grid (2x2 of POI images from itinerary)
  - Right: Title, date created, day count, quick preview, action buttons row
- **Actions:** View, Edit, Delete, Export JSON (icon buttons with tooltips)
- **Empty State:** Illustration + "Create your first itinerary" CTA

### Travel History Tab
- **Layout:** Timeline style or card list
- **Card Structure:** Place name, visit date, booking ID, rating stars, notes preview, expand button
- **Enhancement:** Month/year grouping headers, filter by year/rating

---

## Itinerary Generator (/itinerary/generate)

**Page Layout:** Two-column split on desktop (form left 40%, preview/info right 60%)

### Form Section (Left Column)
- **Container:** Sticky position during scroll
- **Components:**
  - Number input: "How many days?" (1-7 range with +/- buttons)
  - Multi-select chips: "Interests" (Food, Heritage, Nature, Adventure, Shopping, etc.)
  - Range slider: "Budget Level" (Budget/Moderate/Luxury)
  - Radio cards: "Travel Mode" (Walking, Public Transport, Private Car)
  - Large primary button: "Generate Itinerary" with AI sparkle icon
- **Spacing:** space-y-6 between form groups

### Preview Section (Right Column)
- **Initial State:** Illustration + helper text explaining how AI generates personalized itineraries
- **Loading State:** Skeleton loaders showing day cards being generated
- **Generated State:** Day-by-day accordion/expandable cards

### Generated Itinerary Display
- **Layout:** Vertical stack of day cards with timeline connector
- **Day Card Structure:**
  - Header: "Day 1", time range, summary
  - POI List: Each POI with small image (80px square), name, time, address, notes
  - Footer: Map preview thumbnail
- **Actions Bar:** Sticky bottom with "Save Itinerary" primary button, "Regenerate" secondary button

---

## Component Library

### Navigation Bar
- **Desktop:** Horizontal with logo left, nav links center, user menu/auth buttons right
- **Mobile:** Hamburger menu with slide-out drawer
- **State Indicators:** User avatar if authenticated, login/signup buttons if not

### Trail/POI Cards
- **Image:** 16:9 aspect ratio, object-cover, rounded-lg
- **Overlay Elements:** Category badge (top-left), favorite button (top-right)
- **Content:** Title, location with icon, rating stars, quick stats row
- **Interaction:** Subtle shadow on hover, scale transform on click

### Form Inputs
- **Text Inputs:** Floating labels or always-visible labels, border focus states
- **Multi-Select:** Chip-based with x-to-remove, add button
- **Range Slider:** Custom track with value indicator
- **Radio Cards:** Full card clickable with visual selected state

### Buttons
- **Primary:** Rounded-lg, px-6 py-3, font-medium
- **Secondary:** Outlined style with transparent background
- **Icon Buttons:** 40px square or circle, centered icon
- **Button Groups:** Connected with no gap, first/last rounded

### Modals
- **Auth Modal:** Centered, max-w-md, tabs for login/signup
- **Confirmation Dialogs:** Centered, max-w-sm, clear action buttons
- **Backdrop:** Blur effect with subtle overlay

### Loading States
- **Skeleton Loaders:** Match component dimensions with shimmer animation
- **Spinners:** Centered with loading text for full-page loads
- **Progressive Loading:** Show available content while rest loads

### Empty States
- **Illustration:** Simple SVG or icon
- **Messaging:** Encouraging headline, helpful description, primary CTA
- **Placement:** Centered within section with generous padding

---

## Images Strategy

**Hero Image:**
- Large, high-quality image of Mumbai landmark (Gateway of India, Marine Drive, heritage architecture)
- Position: Top of landing page, full-width, 80vh on desktop
- Treatment: Subtle overlay gradient for text readability

**Trail/POI Images:**
- Source: Each trail card requires 16:9 image
- Fallback: `https://source.unsplash.com/featured/800x600/?mumbai,heritage,food` or `/assets/placeholder-mumbai.jpg`
- Placement: Primary visual element in all trail cards

**Profile/Itinerary Thumbnails:**
- Small square images (80x80px to 200x200px)
- Grid layouts for itinerary previews

**Section Backgrounds:**
- CTA sections: Subtle background image with strong overlay
- Testimonial section: Optional subtle pattern or solid treatment

**Illustrations:**
- Empty states for no itineraries/history
- How It Works section: Simple line icons or small illustrations

---

## Accessibility & Performance

- All images include descriptive alt text
- Fallback handling with onError for all external images
- Icon library: Heroicons via CDN (single library throughout)
- Maintain consistent focus indicators across all interactive elements
- Form labels always visible and associated with inputs
- Minimum touch target size: 44x44px for mobile

---

## Animation Guidelines (Minimal)

**Strategic Use Only:**
- Card hover: Subtle scale (1.02) and shadow increase
- Page transitions: Simple fade-in for route changes
- Loading: Skeleton shimmer animation only
- Scroll reveal: Avoid unless specifically requested

**Forbidden:**
- Parallax effects
- Complex scroll-triggered animations
- Auto-playing carousels
- Distracting micro-interactions