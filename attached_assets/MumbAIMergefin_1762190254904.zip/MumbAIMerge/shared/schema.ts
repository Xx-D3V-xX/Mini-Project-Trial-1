import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  avatarUrl: text("avatar_url"),
  interests: text("interests").array().default(sql`ARRAY[]::text[]`),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Trails table - collections of POIs
export const trails = pgTable("trails", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // Food, Heritage, Nature, Shopping, Adventure
  duration: text("duration").notNull(), // e.g., "2-3 hours", "Half day"
  difficulty: text("difficulty").notNull(), // Easy, Moderate, Challenging
  imageUrl: text("image_url"),
  rating: integer("rating").default(5),
});

export const insertTrailSchema = createInsertSchema(trails).omit({ id: true });
export type InsertTrail = z.infer<typeof insertTrailSchema>;
export type Trail = typeof trails.$inferSelect;

// POIs (Points of Interest) table
export const pois = pgTable("pois", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  address: text("address").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  imageUrl: text("image_url"),
  latitude: text("latitude"),
  longitude: text("longitude"),
  rating: integer("rating").default(5),
  openingHours: text("opening_hours"),
});

export const insertPoiSchema = createInsertSchema(pois).omit({ id: true });
export type InsertPoi = z.infer<typeof insertPoiSchema>;
export type Poi = typeof pois.$inferSelect;

// Itineraries table
export const itineraries = pgTable("itineraries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  title: text("title").notNull(),
  days: integer("days").notNull(),
  summary: text("summary"),
  interests: text("interests").array().default(sql`ARRAY[]::text[]`),
  budget: text("budget"), // Budget, Moderate, Luxury
  travelMode: text("travel_mode"), // Walking, Public Transport, Private Car
  createdAt: timestamp("created_at").defaultNow(),
  // Store daily plan as JSON: [{ day: 1, pois: [{name, time, address, imageUrl, notes}] }]
  dailyPlan: json("daily_plan").$type<Array<{
    day: number;
    pois: Array<{
      id?: string;
      name: string;
      time: string;
      address: string;
      imageUrl?: string;
      notes?: string;
    }>;
  }>>(),
});

export const insertItinerarySchema = createInsertSchema(itineraries).omit({ id: true, createdAt: true });
export type InsertItinerary = z.infer<typeof insertItinerarySchema>;
export type Itinerary = typeof itineraries.$inferSelect;

// Travel History table
export const travelHistory = pgTable("travel_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  placeName: text("place_name").notNull(),
  visitDate: timestamp("visit_date").notNull(),
  bookingId: text("booking_id"),
  notes: text("notes"),
  rating: integer("rating").default(5),
  imageUrl: text("image_url"),
});

export const insertTravelHistorySchema = createInsertSchema(travelHistory).omit({ id: true });
export type InsertTravelHistory = z.infer<typeof insertTravelHistorySchema>;
export type TravelHistory = typeof travelHistory.$inferSelect;

// Auth schemas
export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const registerSchema = loginSchema.extend({
  name: z.string().min(2, "Name must be at least 2 characters"),
});

export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;

// Itinerary generation request schema
export const generateItinerarySchema = z.object({
  days: z.number().min(1).max(7),
  interests: z.array(z.string()).min(1, "Select at least one interest"),
  budget: z.enum(["Budget", "Moderate", "Luxury"]),
  travelMode: z.enum(["Walking", "Public Transport", "Private Car"]),
});

export type GenerateItineraryInput = z.infer<typeof generateItinerarySchema>;
