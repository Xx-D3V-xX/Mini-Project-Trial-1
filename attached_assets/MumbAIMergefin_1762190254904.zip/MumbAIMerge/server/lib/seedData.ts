import { storage } from "../storage";
import type { InsertTrail, InsertPoi } from "@shared/schema";

const trails: InsertTrail[] = [
  {
    title: "Heritage Architecture Tour",
    description: "Explore Mumbai's colonial and Victorian-era architectural marvels including CST, Bombay High Court, and the iconic Gateway of India",
    category: "Heritage",
    duration: "3-4 hours",
    difficulty: "Easy",
    imageUrl: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=800",
    rating: 5,
  },
  {
    title: "Street Food Paradise",
    description: "A culinary journey through Mumbai's most famous food streets including vada pav, pav bhaji, bhel puri, and more local delicacies",
    category: "Food",
    duration: "2-3 hours",
    difficulty: "Easy",
    imageUrl: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800",
    rating: 5,
  },
  {
    title: "Coastal Charm Walk",
    description: "Stroll along Marine Drive, visit Chowpatty Beach, and enjoy the sunset at the iconic Queen's Necklace",
    category: "Nature",
    duration: "2 hours",
    difficulty: "Easy",
    imageUrl: "https://images.unsplash.com/photo-1566552881560-0be862a7c445?w=800",
    rating: 5,
  },
  {
    title: "Colaba Causeway Shopping",
    description: "Experience the vibrant markets of Colaba with fashion boutiques, antique shops, and street vendors",
    category: "Shopping",
    duration: "2-3 hours",
    difficulty: "Moderate",
    imageUrl: "https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?w=800",
    rating: 4,
  },
  {
    title: "Bollywood & Film City Tour",
    description: "Get a behind-the-scenes look at Mumbai's film industry with studio visits and celebrity spotting",
    category: "Adventure",
    duration: "Half day",
    difficulty: "Moderate",
    imageUrl: "https://images.unsplash.com/photo-1594908900066-3f47337549d8?w=800",
    rating: 4,
  },
  {
    title: "Dharavi Community Walk",
    description: "An eye-opening tour through Asia's largest informal settlement, showcasing resilient communities and thriving small industries",
    category: "Adventure",
    duration: "2-3 hours",
    difficulty: "Moderate",
    imageUrl: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800",
    rating: 5,
  },
  {
    title: "Art Deco District Discovery",
    description: "Walk through the world's second-largest collection of Art Deco buildings along Marine Drive and Oval Maidan",
    category: "Heritage",
    duration: "2 hours",
    difficulty: "Easy",
    imageUrl: "https://images.unsplash.com/photo-1582407947304-fd86f028f716?w=800",
    rating: 4,
  },
  {
    title: "Sanjay Gandhi National Park Trek",
    description: "Escape the city buzz with nature trails, ancient Kanheri Caves, and potential leopard sightings",
    category: "Nature",
    duration: "Half day",
    difficulty: "Challenging",
    imageUrl: "https://images.unsplash.com/photo-1501594907352-04cda38ebc29?w=800",
    rating: 5,
  },
];

const pois: InsertPoi[] = [
  {
    name: "Gateway of India",
    address: "Apollo Bandar, Colaba, Mumbai",
    description: "Iconic arch monument overlooking the Arabian Sea",
    category: "Heritage",
    imageUrl: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=800",
    rating: 5,
    openingHours: "Open 24 hours",
    latitude: "18.9220",
    longitude: "72.8347",
  },
  {
    name: "Chhatrapati Shivaji Terminus",
    address: "Victoria Terminus Area, Fort, Mumbai",
    description: "UNESCO World Heritage Victorian Gothic railway station",
    category: "Heritage",
    imageUrl: "https://images.unsplash.com/photo-1606979196820-5d55b34df41a?w=800",
    rating: 5,
    openingHours: "Open 24 hours",
    latitude: "18.9398",
    longitude: "72.8355",
  },
  {
    name: "Marine Drive",
    address: "Marine Drive, Mumbai",
    description: "The Queen's Necklace - a picturesque promenade",
    category: "Nature",
    imageUrl: "https://images.unsplash.com/photo-1566552881560-0be862a7c445?w=800",
    rating: 5,
    openingHours: "Open 24 hours",
    latitude: "18.9432",
    longitude: "72.8236",
  },
  {
    name: "Crawford Market",
    address: "Lokmanya Tilak Marg, Mumbai",
    description: "Historic market with fresh produce and exotic goods",
    category: "Shopping",
    imageUrl: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800",
    rating: 4,
    openingHours: "9 AM - 8 PM",
    latitude: "18.9470",
    longitude: "72.8341",
  },
  {
    name: "Elephanta Caves",
    address: "Elephanta Island, Mumbai Harbor",
    description: "Ancient rock-cut temples dedicated to Lord Shiva",
    category: "Heritage",
    imageUrl: "https://images.unsplash.com/photo-1609137144813-7d9921338f24?w=800",
    rating: 5,
    openingHours: "9 AM - 5:30 PM (Closed Monday)",
    latitude: "18.9633",
    longitude: "72.9315",
  },
];

export async function seedInitialData() {
  try {
    // Check if data already exists
    const existingTrails = await storage.getAllTrails();
    if (existingTrails.length > 0) {
      console.log("Data already seeded");
      return;
    }

    // Seed trails
    for (const trail of trails) {
      await storage.createTrail(trail);
    }

    // Seed POIs
    for (const poi of pois) {
      await storage.createPoi(poi);
    }

    console.log("Successfully seeded initial data:");
    console.log(`- ${trails.length} trails`);
    console.log(`- ${pois.length} POIs`);
  } catch (error) {
    console.error("Error seeding data:", error);
  }
}
