import type { GenerateItineraryInput, Itinerary } from "@shared/schema";
import { storage } from "../storage";
import { randomUUID } from "crypto";

// Mock algorithm for generating itineraries
export async function generateItinerary(
  input: GenerateItineraryInput,
  userId: string
): Promise<Itinerary> {
  const { days, interests, budget, travelMode } = input;

  // Get all POIs from storage
  const allPois = await storage.getAllPois();

  // Filter POIs based on interests
  const relevantPois = allPois.filter((poi) =>
    interests.some((interest) =>
      interest.toLowerCase().includes(poi.category.toLowerCase()) ||
      poi.category.toLowerCase().includes(interest.toLowerCase())
    )
  );

  // If no matching POIs, use all POIs
  const poisToUse = relevantPois.length > 0 ? relevantPois : allPois;

  // Generate daily plan
  const dailyPlan = [];
  const poisPerDay = Math.min(Math.ceil(poisToUse.length / days), 4);

  const timeSlots = ["9:00 AM", "11:30 AM", "2:00 PM", "4:30 PM", "7:00 PM"];

  for (let day = 1; day <= days; day++) {
    const startIndex = (day - 1) * poisPerDay;
    const dayPois = poisToUse.slice(startIndex, startIndex + poisPerDay);

    const pois = dayPois.map((poi, index) => ({
      id: poi.id,
      name: poi.name,
      time: timeSlots[index % timeSlots.length],
      address: poi.address,
      imageUrl: poi.imageUrl || undefined,
      notes: poi.description || undefined,
    }));

    dailyPlan.push({ day, pois });
  }

  // Generate title based on interests
  const primaryInterest = interests[0] || "Mumbai";
  const title = `${days}-Day ${primaryInterest} Experience`;

  // Generate summary
  const budgetDesc = budget === "Budget" ? "budget-friendly" : budget === "Luxury" ? "premium" : "comfortable";
  const summary = `A ${days}-day ${budgetDesc} Mumbai itinerary focused on ${interests.join(", ")}. Travel by ${travelMode.toLowerCase()} to explore the best of what Mumbai has to offer.`;

  const itinerary: Itinerary = {
    id: randomUUID(),
    userId,
    title,
    days,
    summary,
    interests,
    budget,
    travelMode,
    dailyPlan,
    createdAt: new Date(),
  };

  return itinerary;
}
