import {
  type User,
  type InsertUser,
  type Trail,
  type InsertTrail,
  type Poi,
  type InsertPoi,
  type Itinerary,
  type InsertItinerary,
  type TravelHistory,
  type InsertTravelHistory,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Trail operations
  getAllTrails(): Promise<Trail[]>;
  getTrailById(id: string): Promise<Trail | undefined>;
  createTrail(trail: InsertTrail): Promise<Trail>;

  // POI operations
  getAllPois(): Promise<Poi[]>;
  getPoiById(id: string): Promise<Poi | undefined>;
  createPoi(poi: InsertPoi): Promise<Poi>;

  // Itinerary operations
  getItinerariesByUser(userId: string): Promise<Itinerary[]>;
  getItineraryById(id: string): Promise<Itinerary | undefined>;
  createItinerary(itinerary: InsertItinerary): Promise<Itinerary>;
  deleteItinerary(id: string): Promise<boolean>;

  // Travel history operations
  getTravelHistoryByUser(userId: string): Promise<TravelHistory[]>;
  createTravelHistory(history: InsertTravelHistory): Promise<TravelHistory>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private trails: Map<string, Trail>;
  private pois: Map<string, Poi>;
  private itineraries: Map<string, Itinerary>;
  private travelHistory: Map<string, TravelHistory>;

  constructor() {
    this.users = new Map();
    this.trails = new Map();
    this.pois = new Map();
    this.itineraries = new Map();
    this.travelHistory = new Map();
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find((user) => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id, avatarUrl: null, interests: [] };
    this.users.set(id, user);
    return user;
  }

  // Trail operations
  async getAllTrails(): Promise<Trail[]> {
    return Array.from(this.trails.values());
  }

  async getTrailById(id: string): Promise<Trail | undefined> {
    return this.trails.get(id);
  }

  async createTrail(insertTrail: InsertTrail): Promise<Trail> {
    const id = randomUUID();
    const trail: Trail = { ...insertTrail, id };
    this.trails.set(id, trail);
    return trail;
  }

  // POI operations
  async getAllPois(): Promise<Poi[]> {
    return Array.from(this.pois.values());
  }

  async getPoiById(id: string): Promise<Poi | undefined> {
    return this.pois.get(id);
  }

  async createPoi(insertPoi: InsertPoi): Promise<Poi> {
    const id = randomUUID();
    const poi: Poi = { ...insertPoi, id };
    this.pois.set(id, poi);
    return poi;
  }

  // Itinerary operations
  async getItinerariesByUser(userId: string): Promise<Itinerary[]> {
    return Array.from(this.itineraries.values())
      .filter((itinerary) => itinerary.userId === userId)
      .sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      });
  }

  async getItineraryById(id: string): Promise<Itinerary | undefined> {
    return this.itineraries.get(id);
  }

  async createItinerary(insertItinerary: InsertItinerary): Promise<Itinerary> {
    const id = randomUUID();
    const itinerary: Itinerary = {
      ...insertItinerary,
      id,
      createdAt: new Date(),
    };
    this.itineraries.set(id, itinerary);
    return itinerary;
  }

  async deleteItinerary(id: string): Promise<boolean> {
    return this.itineraries.delete(id);
  }

  // Travel history operations
  async getTravelHistoryByUser(userId: string): Promise<TravelHistory[]> {
    return Array.from(this.travelHistory.values())
      .filter((history) => history.userId === userId)
      .sort((a, b) => {
        const dateA = new Date(a.visitDate).getTime();
        const dateB = new Date(b.visitDate).getTime();
        return dateB - dateA;
      });
  }

  async createTravelHistory(insertHistory: InsertTravelHistory): Promise<TravelHistory> {
    const id = randomUUID();
    const history: TravelHistory = { ...insertHistory, id };
    this.travelHistory.set(id, history);
    return history;
  }
}

export const storage = new MemStorage();
