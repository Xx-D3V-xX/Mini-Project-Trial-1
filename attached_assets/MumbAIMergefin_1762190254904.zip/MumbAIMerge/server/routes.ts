import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { authMiddleware, optionalAuth, type AuthRequest } from "./middleware/auth";
import { generateToken, hashPassword } from "./lib/jwt";
import { seedInitialData } from "./lib/seedData";
import { generateItinerary } from "./lib/itineraryGenerator";
import {
  loginSchema,
  registerSchema,
  generateItinerarySchema,
  insertItinerarySchema,
  insertTravelHistorySchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Seed initial data
  await seedInitialData();

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      const { email, password, name } = validatedData;

      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }

      const hashedPassword = hashPassword(password);
      const user = await storage.createUser({
        email,
        password: hashedPassword,
        name,
      });

      const token = generateToken(user.id, user.email);

      const { password: _, ...userWithoutPassword } = user;
      res.json({ token, user: userWithoutPassword });
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      const { email, password } = validatedData;

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const hashedPassword = hashPassword(password);
      if (user.password !== hashedPassword) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const token = generateToken(user.id, user.email);

      const { password: _, ...userWithoutPassword } = user;
      res.json({ token, user: userWithoutPassword });
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Login failed" });
    }
  });

  app.get("/api/auth/validate", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.userId!);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }

      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(500).json({ message: "Validation failed" });
    }
  });

  // Profile routes
  app.get("/api/profile", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.get("/api/profile/itineraries", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const itineraries = await storage.getItinerariesByUser(req.userId!);
      res.json(itineraries);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch itineraries" });
    }
  });

  app.post("/api/profile/itineraries", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const itineraryData = {
        ...req.body,
        userId: req.userId,
      };

      const itinerary = await storage.createItinerary(itineraryData);
      res.json(itinerary);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to save itinerary" });
    }
  });

  app.get("/api/profile/history", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const history = await storage.getTravelHistoryByUser(req.userId!);
      res.json(history);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch travel history" });
    }
  });

  app.post("/api/profile/history", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const validatedData = insertTravelHistorySchema.parse({
        ...req.body,
        userId: req.userId,
      });

      const history = await storage.createTravelHistory(validatedData);
      res.json(history);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to add travel history" });
    }
  });

  // Trail routes
  app.get("/api/trails", optionalAuth, async (req: AuthRequest, res) => {
    try {
      const trails = await storage.getAllTrails();
      res.json(trails);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch trails" });
    }
  });

  app.get("/api/trails/:id", optionalAuth, async (req: AuthRequest, res) => {
    try {
      const trail = await storage.getTrailById(req.params.id);
      if (!trail) {
        return res.status(404).json({ message: "Trail not found" });
      }
      res.json(trail);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch trail" });
    }
  });

  // POI routes
  app.get("/api/pois", optionalAuth, async (req: AuthRequest, res) => {
    try {
      const pois = await storage.getAllPois();
      res.json(pois);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch POIs" });
    }
  });

  // Itinerary generation
  app.post("/api/itinerary/generate", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const validatedData = generateItinerarySchema.parse(req.body);
      const itinerary = await generateItinerary(validatedData, req.userId!);
      res.json(itinerary);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to generate itinerary" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
