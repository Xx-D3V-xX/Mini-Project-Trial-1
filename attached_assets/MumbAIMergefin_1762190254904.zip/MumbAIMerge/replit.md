# MumbAI Trails

## Overview

MumbAI Trails is a travel discovery platform for Mumbai that combines curated walking trails with AI-powered itinerary generation. The application helps users explore Mumbai's food, heritage, and nature attractions through personalized experiences. It features user authentication, profile management with travel history, and an AI-powered itinerary generator that creates custom multi-day plans based on user preferences.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System:**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server for fast HMR and optimized builds
- Wouter for client-side routing (lightweight alternative to React Router)

**UI Component System:**
- shadcn/ui components built on Radix UI primitives for accessible, customizable components
- Tailwind CSS with custom design tokens for styling
- Custom theme system supporting light/dark modes via CSS variables
- Design follows travel platform references (Airbnb-style cards, Google Travel itineraries)

**State Management:**
- TanStack Query (React Query) for server state management and caching
- React Context (AuthContext) for global authentication state
- React Hook Form with Zod validation for form state and validation

**Key Design Patterns:**
- Protected routes wrapper component for authentication-required pages
- Token-based authentication with localStorage persistence
- Centralized API request handling with automatic auth header injection
- Image fallback handling for missing or broken images

### Backend Architecture

**Server Framework:**
- Express.js with TypeScript for the REST API
- In-memory storage implementation (MemStorage) as the data layer
- Middleware-based authentication using custom JWT implementation

**API Design:**
- RESTful endpoints organized by resource type (auth, trails, POIs, itineraries, profile)
- Authentication middleware for protected routes with optional auth support
- Request/response logging for API calls
- Zod schemas shared between frontend and backend for runtime validation

**Authentication System:**
- Custom JWT token generation and verification (not using external library)
- HMAC SHA-256 signing for tokens
- Password hashing using Node.js crypto module
- Token stored in localStorage with 7-day expiration
- Validation endpoint for persistent authentication across sessions

**Data Models:**
- Users: authentication and profile information
- Trails: curated walking experiences with categories (Food, Heritage, Nature, Shopping, Adventure)
- POIs (Points of Interest): individual locations with coordinates and metadata
- Itineraries: user-generated or AI-generated multi-day plans
- Travel History: user's visited places with ratings and notes

### AI Itinerary Generation

**Algorithm Approach:**
- Mock/simple algorithm that filters POIs based on user interests
- Distributes POIs across requested number of days (up to 4 POIs per day)
- Assigns time slots to create structured daily schedules
- Generates titles based on primary interest and duration
- Designed to be replaced with actual AI/ML service integration

### External Dependencies

**Database:**
- Currently using in-memory storage (MemStorage class)
- Drizzle ORM configured for PostgreSQL with Neon serverless driver
- Schema defined but not actively used (ready for migration from in-memory to Postgres)
- Database credentials configured via DATABASE_URL environment variable

**Third-Party UI Libraries:**
- Radix UI: Headless component primitives for accessibility
- Embla Carousel: Touch-friendly carousel component
- Lucide React: Icon library
- date-fns: Date formatting and manipulation

**Development Tools:**
- Replit-specific plugins for development environment integration
- TypeScript for type checking across entire codebase
- ESBuild for production server bundling

**Image Assets:**
- Local image assets stored in attached_assets directory
- Unsplash URLs used as fallbacks for trail/POI images
- Image error handling with automatic fallback to default heritage image

**Session Management:**
- connect-pg-simple configured for PostgreSQL session storage (when DB is active)
- Currently relying on JWT tokens stored client-side for stateless authentication