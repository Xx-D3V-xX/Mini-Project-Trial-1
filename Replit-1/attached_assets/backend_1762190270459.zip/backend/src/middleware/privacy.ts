import { Request, Response, NextFunction } from 'express';
import { UserRole, PIILevel } from '@prisma/client';
import { RBACService, Permission } from '../lib/rbac';
import { PIIFilterService, PII_FIELD_MAPPINGS } from '../lib/pii-filter';
import { AuditLogger, AuditAction } from '../lib/audit-logger';

export interface PrivacyMiddlewareOptions {
  requiredPermission?: Permission;
  requireAuth?: boolean;
  logAccess?: boolean;
  minimumRole?: UserRole;
  allowSelfAccess?: boolean;
}

/**
 * Privacy-aware authentication middleware
 */
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.user || !req.user.id) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  next();
}

/**
 * Privacy-aware role-based authorization middleware
 */
export function requireRole(minimumRole: UserRole) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const userRoleLevel = RBACService.ROLE_HIERARCHY[req.user.role];
    const requiredRoleLevel = RBACService.ROLE_HIERARCHY[minimumRole];

    if (userRoleLevel < requiredRoleLevel) {
      return res.status(403).json({ 
        error: 'Insufficient privileges', 
        required: minimumRole,
        current: req.user.role 
      });
    }

    next();
  };
}

/**
 * Privacy-aware permission check middleware
 */
export function requirePermission(permission: Permission) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    if (!RBACService.hasPermission(req.user.role, permission)) {
      return res.status(403).json({ 
        error: 'Permission denied', 
        required: permission 
      });
    }

    next();
  };
}

/**
 * Middleware to check access to user data with PII consideration
 */
export function requireUserAccess(options: {
  targetUserIdParam?: string;
  allowSelfAccess?: boolean;
  maxPIILevel?: PIILevel;
} = {}) {
  const { 
    targetUserIdParam = 'userId', 
    allowSelfAccess = true, 
    maxPIILevel = PIILevel.NONE 
  } = options;

  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const targetUserId = req.params[targetUserIdParam] || req.body.userId;
    
    if (!targetUserId) {
      return res.status(400).json({ error: 'Target user ID required' });
    }

    // Check if user can access the target user's data
    const canAccess = RBACService.canAccessUserData(
      req.user.role,
      req.user.id,
      targetUserId,
      maxPIILevel
    );

    if (!canAccess) {
      // Log unauthorized access attempt
      await AuditLogger.logAction({
        adminId: req.user.id,
        adminRole: req.user.role,
        action: AuditAction.PII_ACCESS,
        targetType: 'user',
        targetId: targetUserId,
        details: {
          unauthorized: true,
          requestedPIILevel: maxPIILevel,
        },
        request: req,
      });

      return res.status(403).json({ 
        error: 'Access denied to user data',
        reason: 'Insufficient privileges for requested data access level'
      });
    }

    // Store context for downstream middleware
    req.privacy = {
      requiresPIIAccess: true,
      targetUserId,
      piiLevel: maxPIILevel,
    };

    next();
  };
}

/**
 * Middleware to filter response data based on user permissions
 */
export function filterPIIResponse(req: Request, res: Response, next: NextFunction) {
  if (!req.user) {
    return next();
  }

  // Store original json method
  const originalJson = res.json;

  // Override json method to filter PII
  res.json = function(data: any) {
    let filteredData = data;

    // Only filter if we have data to filter
    if (data && typeof data === 'object') {
      filteredData = filterResponseData(data, req.user!, req.privacy);
    }

    // Log PII access if required
    if (req.privacy?.requiresPIIAccess && req.privacy.targetUserId) {
      logPIIAccess(req, filteredData);
    }

    // Call original json method with filtered data
    return originalJson.call(this, filteredData);
  };

  next();
}

/**
 * Filter response data based on user permissions and context
 */
function filterResponseData(
  data: any, 
  user: { id: string; role: UserRole }, 
  privacy?: { targetUserId?: string; piiLevel?: PIILevel }
): any {
  if (!data || typeof data !== 'object') {
    return data;
  }

  // Handle arrays
  if (Array.isArray(data)) {
    return data.map(item => filterResponseData(item, user, privacy));
  }

  // Handle single objects
  if (data.userId || data.id) {
    const targetUserId = privacy?.targetUserId || data.userId || data.id;
    return PIIFilterService.filterObject(data, user.role, user.id, targetUserId);
  }

  // Handle nested objects
  const filtered: any = {};
  for (const [key, value] of Object.entries(data)) {
    if (typeof value === 'object' && value !== null) {
      filtered[key] = filterResponseData(value, user, privacy);
    } else {
      // Check if this field is PII
      const piiLevel = PII_FIELD_MAPPINGS[key as keyof typeof PII_FIELD_MAPPINGS];
      if (piiLevel && piiLevel !== PIILevel.NONE) {
        // Apply filtering based on user access
        const canAccess = privacy?.targetUserId 
          ? PIIFilterService.canAccessField(user.role, user.id, privacy.targetUserId, key)
          : false;
        
        filtered[key] = canAccess ? value : '[REDACTED]';
      } else {
        filtered[key] = value;
      }
    }
  }

  return filtered;
}

/**
 * Log PII access for audit purposes
 */
async function logPIIAccess(
  req: Request, 
  responseData: any
): Promise<void> {
  if (!req.user || !req.privacy?.targetUserId) return;

  try {
    // Extract accessed fields from response data
    const fieldsAccessed = extractAccessedFields(responseData);
    
    // Determine highest PII level accessed
    const maxPIILevel = getMaxPIILevelAccessed(fieldsAccessed);

    await AuditLogger.logPIIAccess({
      adminId: req.user.id,
      adminRole: req.user.role,
      action: AuditAction.PII_ACCESS,
      targetUserId: req.privacy.targetUserId,
      piiLevel: maxPIILevel,
      fieldsAccessed,
      purpose: `API access: ${req.method} ${req.path}`,
      request: req,
    });
  } catch (error) {
    console.error('Failed to log PII access:', error);
  }
}

/**
 * Extract field names from response data
 */
function extractAccessedFields(data: any, prefix: string = ''): string[] {
  const fields: string[] = [];
  
  if (!data || typeof data !== 'object') return fields;

  if (Array.isArray(data)) {
    // For arrays, analyze the first item
    if (data.length > 0) {
      return extractAccessedFields(data[0], prefix);
    }
    return fields;
  }

  for (const [key, value] of Object.entries(data)) {
    const fullKey = prefix ? `${prefix}.${key}` : key;
    
    if (typeof value === 'object' && value !== null) {
      fields.push(...extractAccessedFields(value, fullKey));
    } else {
      fields.push(fullKey);
    }
  }

  return fields;
}

/**
 * Get the maximum PII level from a list of field names
 */
function getMaxPIILevelAccessed(fields: string[]): PIILevel {
  let maxLevel: PIILevel = PIILevel.NONE;
  
  for (const field of fields) {
    const baseField = field.split('.').pop(); // Get the last part of nested field names
    const piiLevel = PII_FIELD_MAPPINGS[baseField as keyof typeof PII_FIELD_MAPPINGS];
    
    if (piiLevel) {
      // Compare PII levels (assuming higher enum values = more sensitive)
      if (Object.values(PIILevel).indexOf(piiLevel) > Object.values(PIILevel).indexOf(maxLevel)) {
        maxLevel = piiLevel;
      }
    }
  }
  
  return maxLevel;
}

/**
 * Comprehensive privacy middleware that combines all protections
 */
export function createPrivacyMiddleware(options: PrivacyMiddlewareOptions = {}) {
  const middlewares = [];

  // Authentication if required
  if (options.requireAuth !== false) {
    middlewares.push(requireAuth);
  }

  // Role check if specified
  if (options.minimumRole) {
    middlewares.push(requireRole(options.minimumRole));
  }

  // Permission check if specified
  if (options.requiredPermission) {
    middlewares.push(requirePermission(options.requiredPermission));
  }

  // PII filtering for responses
  middlewares.push(filterPIIResponse);

  // Audit logging if enabled
  if (options.logAccess !== false) {
    middlewares.push(AuditLogger.createMiddleware());
  }

  // Return combined middleware
  return middlewares;
}

/**
 * Express error handler for privacy-related errors
 */
export function privacyErrorHandler(
  error: any, 
  req: Request, 
  res: Response, 
  next: NextFunction
) {
  // Log privacy violations for audit purposes
  if (error.type === 'privacy_violation' && req.user) {
    AuditLogger.logAction({
      adminId: req.user.id,
      adminRole: req.user.role,
      action: AuditAction.PII_ACCESS,
      details: {
        error: error.message,
        unauthorized: true,
      },
      request: req,
    }).catch(auditError => {
      console.error('Failed to log privacy violation:', auditError);
    });
  }

  // Standard error handling
  if (error.name === 'UnauthorizedError' || error.status === 401) {
    return res.status(401).json({ error: 'Unauthorized access' });
  }

  if (error.name === 'ForbiddenError' || error.status === 403) {
    return res.status(403).json({ error: 'Access forbidden' });
  }

  next(error);
}