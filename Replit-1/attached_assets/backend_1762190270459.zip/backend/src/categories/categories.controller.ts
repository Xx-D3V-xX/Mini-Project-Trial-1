import { Controller, Get, Post, Body } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { CategoriesService } from './categories.service';

@ApiTags('categories')
@Controller('categories')
export class CategoriesController {
  constructor(private readonly categoriesService: CategoriesService) {}

  @Get()
  async findAll() {
    return { message: 'Categories endpoint - implementation pending', data: [] };
  }

  @Post()
  async create(@Body() createDto: any) {
    return { message: 'Create category endpoint - implementation pending' };
  }
}