import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/services/prisma.service';

@Injectable()
export class CategoriesService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll() {
    return [];
  }

  async create(data: any) {
    return { message: 'Category creation not implemented yet' };
  }
}