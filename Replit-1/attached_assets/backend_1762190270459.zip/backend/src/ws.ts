import { Server as SocketIOServer } from 'socket.io';
import { Server as HttpServer } from 'http';
import { z } from 'zod';
import { verifyAccessToken } from './lib/jwt';
import { prisma } from './db/prisma';

const joinRoomSchema = z.object({
  sessionId: z.string().uuid()
});

const messageSchema = z.object({
  sessionId: z.string().uuid(),
  role: z.enum(['user', 'assistant', 'system']),
  content: z.string().max(20000),
  meta: z.record(z.any()).optional()
});

const typingSchema = z.object({
  sessionId: z.string().uuid(),
  isTyping: z.boolean()
});

const feedbackSchema = z.object({
  messageId: z.string().uuid(),
  rating: z.number().int().min(-1).max(1),
  reasonTag: z.string().max(50).optional(),
  notes: z.string().max(1000).optional()
});

interface AuthenticatedSocket {
  userId: string;
  userEmail: string;
}

export function setupWebSocketServer(httpServer: HttpServer) {
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
      methods: ['GET', 'POST']
    },
    namespace: '/chat'
  });

  const chatNamespace = io.of('/chat');

  chatNamespace.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token || socket.handshake.query.token;
      
      if (!token) {
        return next(new Error('Authentication token required'));
      }
      
      const decoded = verifyAccessToken(token as string);
      (socket as any).userId = decoded.userId;
      (socket as any).userEmail = decoded.email;
      
      next();
    } catch (error) {
      next(new Error('Invalid authentication token'));
    }
  });

  chatNamespace.on('connection', (socket) => {
    const authSocket = socket as any as AuthenticatedSocket;
    console.log(`User ${authSocket.userId} connected to chat`);

    // Handle joining a chat session room
    socket.on('chat:join', async (data) => {
      try {
        const { sessionId } = joinRoomSchema.parse(data);
        
        // Verify session ownership
        const session = await prisma.chatSession.findFirst({
          where: { 
            id: sessionId,
            userId: authSocket.userId
          }
        });
        
        if (!session) {
          socket.emit('error', { message: 'Session not found or access denied' });
          return;
        }
        
        socket.join(`session:${sessionId}`);
        socket.emit('chat:joined', { sessionId });
        
        // Log the join event
        await prisma.chatEventLog.create({
          data: {
            sessionId,
            type: 'session_joined',
            payload: { userId: authSocket.userId }
          }
        });
        
      } catch (error) {
        socket.emit('error', { message: 'Invalid join request' });
      }
    });

    // Handle chat messages
    socket.on('chat:message', async (data) => {
      try {
        const { sessionId, role, content, meta } = messageSchema.parse(data);
        
        // Verify session ownership
        const session = await prisma.chatSession.findFirst({
          where: { 
            id: sessionId,
            userId: authSocket.userId
          }
        });
        
        if (!session) {
          socket.emit('error', { message: 'Session not found or access denied' });
          return;
        }
        
        // Create message and update session activity
        const result = await prisma.$transaction(async (tx) => {
          const message = await tx.chatMessage.create({
            data: {
              sessionId,
              userId: authSocket.userId,
              role,
              content,
              meta: meta || {}
            }
          });
          
          await tx.chatSession.update({
            where: { id: sessionId },
            data: { lastActivityAt: new Date() }
          });
          
          return message;
        });
        
        // Emit message to session room
        chatNamespace.to(`session:${sessionId}`).emit('chat:message', {
          messageId: result.id,
          sessionId,
          role,
          content,
          createdAt: result.createdAt,
          meta: result.meta
        });
        
        // Send confirmation back to sender
        socket.emit('chat:message:sent', { messageId: result.id });
        
      } catch (error) {
        if (error instanceof z.ZodError) {
          socket.emit('error', { message: 'Invalid message format', details: error.errors });
        } else {
          console.error('Chat message error:', error);
          socket.emit('error', { message: 'Failed to send message' });
        }
      }
    });

    // Handle typing indicators
    socket.on('chat:typing', async (data) => {
      try {
        const { sessionId, isTyping } = typingSchema.parse(data);
        
        // Verify session ownership
        const session = await prisma.chatSession.findFirst({
          where: { 
            id: sessionId,
            userId: authSocket.userId
          }
        });
        
        if (!session) {
          socket.emit('error', { message: 'Session not found or access denied' });
          return;
        }
        
        // Broadcast typing status to other users in the session
        socket.to(`session:${sessionId}`).emit('chat:typing', {
          userId: authSocket.userId,
          isTyping
        });
        
      } catch (error) {
        socket.emit('error', { message: 'Invalid typing request' });
      }
    });

    // Handle feedback
    socket.on('chat:feedback', async (data) => {
      try {
        const { messageId, rating, reasonTag, notes } = feedbackSchema.parse(data);
        
        // Verify message exists and user owns the session
        const message = await prisma.chatMessage.findFirst({
          where: { 
            id: messageId,
            session: { userId: authSocket.userId }
          }
        });
        
        if (!message) {
          socket.emit('error', { message: 'Message not found or access denied' });
          return;
        }
        
        const feedback = await prisma.chatFeedback.create({
          data: {
            messageId,
            userId: authSocket.userId,
            rating,
            reasonTag,
            notes
          }
        });
        
        // Emit feedback summary to session room
        chatNamespace.to(`session:${message.sessionId}`).emit('chat:feedback:received', {
          messageId,
          rating,
          feedbackId: feedback.id
        });
        
        socket.emit('chat:feedback:sent', { feedbackId: feedback.id });
        
      } catch (error) {
        if (error instanceof z.ZodError) {
          socket.emit('error', { message: 'Invalid feedback format', details: error.errors });
        } else {
          console.error('Chat feedback error:', error);
          socket.emit('error', { message: 'Failed to submit feedback' });
        }
      }
    });

    socket.on('disconnect', () => {
      console.log(`User ${authSocket.userId} disconnected from chat`);
    });
  });

  return io;
}