import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../db/prisma';
import { authenticateToken, AuthenticatedRequest } from '../middleware/auth';

const router = Router();

const createSessionSchema = z.object({
  modelConfig: z.record(z.any()).optional(),
  tags: z.array(z.string()).optional()
});

const createMessageSchema = z.object({
  sessionId: z.string().uuid(),
  role: z.enum(['user', 'assistant', 'system']),
  content: z.string().max(20000),
  tokensIn: z.number().int().min(0).optional(),
  tokensOut: z.number().int().min(0).optional(),
  latencyMs: z.number().int().min(0).optional(),
  meta: z.record(z.any()).optional()
});

const createFeedbackSchema = z.object({
  messageId: z.string().uuid(),
  rating: z.number().int().min(-1).max(1),
  reasonTag: z.string().max(50).optional(),
  notes: z.string().max(1000).optional()
});

// Apply auth middleware to all routes
router.use(authenticateToken);

// POST /chat/sessions
router.post('/sessions', async (req: AuthenticatedRequest, res) => {
  try {
    const { modelConfig, tags } = createSessionSchema.parse(req.body);
    
    const session = await prisma.chatSession.create({
      data: {
        userId: req.userId!,
        modelConfig: modelConfig || {},
        tags: tags || []
      }
    });
    
    res.status(201).json({ sessionId: session.id });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: error.errors });
    }
    console.error('Create session error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /chat/sessions/:id/messages
router.get('/sessions/:id/messages', async (req: AuthenticatedRequest, res) => {
  try {
    const sessionId = req.params.id;
    
    // Verify session ownership
    const session = await prisma.chatSession.findFirst({
      where: { 
        id: sessionId,
        userId: req.userId!
      }
    });
    
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }
    
    const messages = await prisma.chatMessage.findMany({
      where: { sessionId },
      orderBy: { createdAt: 'asc' },
      select: {
        id: true,
        role: true,
        content: true,
        tokensIn: true,
        tokensOut: true,
        latencyMs: true,
        createdAt: true,
        meta: true
      }
    });
    
    res.json({ messages });
  } catch (error) {
    console.error('Get messages error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /chat/messages
router.post('/messages', async (req: AuthenticatedRequest, res) => {
  try {
    const { sessionId, role, content, tokensIn, tokensOut, latencyMs, meta } = createMessageSchema.parse(req.body);
    
    // Verify session ownership
    const session = await prisma.chatSession.findFirst({
      where: { 
        id: sessionId,
        userId: req.userId!
      }
    });
    
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }
    
    // Create message and update session activity in transaction
    const result = await prisma.$transaction(async (tx) => {
      const message = await tx.chatMessage.create({
        data: {
          sessionId,
          userId: req.userId!,
          role,
          content,
          tokensIn: tokensIn || 0,
          tokensOut: tokensOut || 0,
          latencyMs,
          meta: meta || {}
        }
      });
      
      await tx.chatSession.update({
        where: { id: sessionId },
        data: { lastActivityAt: new Date() }
      });
      
      return message;
    });
    
    res.status(201).json({ messageId: result.id });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: error.errors });
    }
    console.error('Create message error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /chat/feedback
router.post('/feedback', async (req: AuthenticatedRequest, res) => {
  try {
    const { messageId, rating, reasonTag, notes } = createFeedbackSchema.parse(req.body);
    
    // Verify message exists and user owns the session
    const message = await prisma.chatMessage.findFirst({
      where: { 
        id: messageId,
        session: { userId: req.userId! }
      }
    });
    
    if (!message) {
      return res.status(404).json({ error: 'Message not found' });
    }
    
    const feedback = await prisma.chatFeedback.create({
      data: {
        messageId,
        userId: req.userId!,
        rating,
        reasonTag,
        notes
      }
    });
    
    res.status(201).json({ feedbackId: feedback.id });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: error.errors });
    }
    console.error('Create feedback error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;