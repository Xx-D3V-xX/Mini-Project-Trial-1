import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../db/prisma';
import { 
  hashPassword, 
  comparePassword, 
  generateTokenPair, 
  verifyRefreshToken, 
  hashRefreshToken, 
  compareRefreshToken,
  getRefreshTokenExpiry 
} from '../lib/jwt';

const router = Router();

const signupSchema = z.object({
  email: z.string().email().max(255),
  password: z.string().min(8).max(128),
  displayName: z.string().max(100).optional()
});

const loginSchema = z.object({
  email: z.string().email().max(255),
  password: z.string().max(128)
});

const refreshSchema = z.object({
  refreshToken: z.string()
});

// POST /auth/signup
router.post('/signup', async (req, res) => {
  try {
    const { email, password, displayName } = signupSchema.parse(req.body);
    
    // Check if user exists
    const existingUser = await prisma.userAccount.findUnique({
      where: { email }
    });
    
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }
    
    // Create user
    const passwordHash = await hashPassword(password);
    const user = await prisma.userAccount.create({
      data: {
        email,
        passwordHash,
        displayName
      }
    });
    
    // Generate tokens
    const { accessToken, refreshToken } = generateTokenPair(user.id, user.email);
    const refreshTokenHash = await hashRefreshToken(refreshToken);
    
    // Store refresh token
    await prisma.userSession.create({
      data: {
        userId: user.id,
        refreshTokenHash,
        userAgent: req.get('User-Agent'),
        ipAddress: req.ip,
        expiresAt: getRefreshTokenExpiry()
      }
    });
    
    res.status(201).json({ accessToken, refreshToken });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: error.errors });
    }
    console.error('Signup error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = loginSchema.parse(req.body);
    
    // Find user
    const user = await prisma.userAccount.findUnique({
      where: { email }
    });
    
    if (!user || user.status !== 'active') {
      return res.status(400).json({ error: 'Invalid credentials' });
    }
    
    // Verify password
    const isValid = await comparePassword(password, user.passwordHash);
    if (!isValid) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }
    
    // Generate tokens
    const { accessToken, refreshToken } = generateTokenPair(user.id, user.email);
    const refreshTokenHash = await hashRefreshToken(refreshToken);
    
    // Store refresh token
    await prisma.userSession.create({
      data: {
        userId: user.id,
        refreshTokenHash,
        userAgent: req.get('User-Agent'),
        ipAddress: req.ip,
        expiresAt: getRefreshTokenExpiry()
      }
    });
    
    res.json({ accessToken, refreshToken });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: error.errors });
    }
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /auth/refresh
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = refreshSchema.parse(req.body);
    
    // Verify token
    const decoded = verifyRefreshToken(refreshToken);
    
    // Find and validate session
    const sessions = await prisma.userSession.findMany({
      where: { 
        userId: decoded.userId,
        expiresAt: { gt: new Date() },
        revokedAt: null
      }
    });
    
    let validSession = null;
    for (const session of sessions) {
      if (await compareRefreshToken(refreshToken, session.refreshTokenHash)) {
        validSession = session;
        break;
      }
    }
    
    if (!validSession) {
      return res.status(403).json({ error: 'Invalid refresh token' });
    }
    
    // Revoke old session
    await prisma.userSession.update({
      where: { id: validSession.id },
      data: { revokedAt: new Date() }
    });
    
    // Generate new tokens
    const { accessToken, refreshToken: newRefreshToken } = generateTokenPair(decoded.userId, decoded.email);
    const refreshTokenHash = await hashRefreshToken(newRefreshToken);
    
    // Create new session
    await prisma.userSession.create({
      data: {
        userId: decoded.userId,
        refreshTokenHash,
        userAgent: req.get('User-Agent'),
        ipAddress: req.ip,
        expiresAt: getRefreshTokenExpiry()
      }
    });
    
    res.json({ accessToken, refreshToken: newRefreshToken });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation error', details: error.errors });
    }
    console.error('Refresh error:', error);
    res.status(403).json({ error: 'Invalid refresh token' });
  }
});

export default router;