import { CorsOptions } from '@nestjs/common/interfaces/external/cors-options.interface';

export function createCorsConfig(): CorsOptions {
  const origins = process.env.CORS_ORIGINS?.split(',') || ['http://localhost:5173'];

  return {
    origin: origins,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
  };
}