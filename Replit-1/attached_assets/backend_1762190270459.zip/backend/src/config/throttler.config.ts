import { ConfigService } from '@nestjs/config';
import { ThrottlerModuleOptions } from '@nestjs/throttler';

export const getThrottlerConfig = (configService: ConfigService): ThrottlerModuleOptions => {
  return {
    throttlers: [
      {
        ttl: configService.get('rateLimit.windowMs') || 60000,
        limit: configService.get('rateLimit.max') || 100,
      },
    ],
  };
};
