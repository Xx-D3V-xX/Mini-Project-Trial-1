import * as Joi from 'joi';

export const validationSchema = Joi.object({
  // Server
  PORT: Joi.number().default(4000),
  NODE_ENV: Joi.string().valid('development', 'production', 'test').default('development'),
  CORS_ORIGINS: Joi.string().default('http://localhost:5173'),

  // Database
  DATABASE_URL: Joi.string().required(),
  PGVECTOR_ENABLED: Joi.boolean().default(false),

  // JWT
  JWT_ACCESS_SECRET: Joi.string().required(),
  JWT_REFRESH_SECRET: Joi.string().required(),
  JWT_ACCESS_TTL: Joi.string().default('15m'),
  JWT_REFRESH_TTL: Joi.string().default('7d'),

  // OAuth
  GOOGLE_OAUTH_CLIENT_ID: Joi.string().allow('').optional(),
  GOOGLE_OAUTH_CLIENT_SECRET: Joi.string().allow('').optional(),
  OAUTH_REDIRECT_URI: Joi.string().allow('').optional(),

  // Third-party APIs
  MAPS_API_KEY: Joi.string().allow('').optional(),
  WEATHER_API_KEY: Joi.string().allow('').optional(),

  // AI Service
  AI_MODEL_INTERNAL_URL: Joi.string().default('http://localhost:8001'),
  AI_INTERNAL_TOKEN: Joi.string().allow('').optional(),

  // Rate limiting
  RATE_LIMIT_WINDOW_MS: Joi.number().default(60000),
  RATE_LIMIT_MAX: Joi.number().default(100),

  // Logging
  LOG_LEVEL: Joi.string().valid('error', 'warn', 'info', 'debug').default('info'),
});