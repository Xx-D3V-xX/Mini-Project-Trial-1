import { DocumentBuilder } from '@nestjs/swagger';

export function createSwaggerConfig() {
  return new DocumentBuilder()
    .setTitle('MumbAI Trails API')
    .setDescription('Backend API for MumbAI Trails smart tourism platform')
    .setVersion('1.0')
    .addBearerAuth(
      {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        name: 'JWT',
        description: 'Enter JWT token',
        in: 'header',
      },
      'JWT-auth',
    )
    .addTag('auth', 'Authentication endpoints')
    .addTag('users', 'User management')
    .addTag('poi', 'Points of Interest')
    .addTag('categories', 'POI Categories')
    .addTag('tags', 'POI Tags')
    .addTag('itineraries', 'Travel Itineraries')
    .addTag('reviews', 'POI Reviews')
    .addTag('favorites', 'User Favorites')
    .addTag('files', 'File Management')
    .addTag('ai', 'AI Services Proxy')
    .build();
}