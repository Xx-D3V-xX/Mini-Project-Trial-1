export default () => ({
  port: parseInt(process.env.PORT, 10) || 4000,
  nodeEnv: process.env.NODE_ENV || 'development',
  
  cors: {
    origins: process.env.CORS_ORIGINS?.split(',') || ['http://localhost:5173'],
  },

  database: {
    url: process.env.DATABASE_URL,
    pgvectorEnabled: process.env.PGVECTOR_ENABLED === 'true',
  },

  jwt: {
    accessSecret: process.env.JWT_ACCESS_SECRET,
    refreshSecret: process.env.JWT_REFRESH_SECRET,
    accessTtl: process.env.JWT_ACCESS_TTL || '15m',
    refreshTtl: process.env.JWT_REFRESH_TTL || '7d',
  },

  oauth: {
    google: {
      clientId: process.env.GOOGLE_OAUTH_CLIENT_ID,
      clientSecret: process.env.GOOGLE_OAUTH_CLIENT_SECRET,
      redirectUri: process.env.OAUTH_REDIRECT_URI || 'http://localhost:4000/auth/google/callback',
    },
  },

  thirdParty: {
    maps: {
      apiKey: process.env.MAPS_API_KEY,
    },
    weather: {
      apiKey: process.env.WEATHER_API_KEY,
    },
  },

  ai: {
    internalUrl: process.env.AI_MODEL_INTERNAL_URL || 'http://localhost:8001',
    internalToken: process.env.AI_INTERNAL_TOKEN,
  },

  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS, 10) || 60000,
    max: parseInt(process.env.RATE_LIMIT_MAX, 10) || 100,
  },

  logging: {
    level: process.env.LOG_LEVEL || 'info',
  },
});