import { Module } from '@nestjs/common';
import { ThrottlerModule } from '@nestjs/throttler';
import { ConfigModule } from './config/config.module';
import { ConfigService } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { PoiModule } from './poi/poi.module';
import { CategoriesModule } from './categories/categories.module';
import { TagsModule } from './tags/tags.module';
import { ItinerariesModule } from './itineraries/itineraries.module';
import { ReviewsModule } from './reviews/reviews.module';
import { FavoritesModule } from './favorites/favorites.module';
import { FilesModule } from './files/files.module';
import { AiModule } from './ai/ai.module';
import { PrismaService } from './common/services/prisma.service';
import { getThrottlerConfig } from './config/throttler.config';

@Module({
  imports: [
    // Configuration
    ConfigModule,
    
    // Rate limiting
    ThrottlerModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: getThrottlerConfig,
      inject: [ConfigService],
    }),
    
    // Feature modules
    AuthModule,
    UsersModule,
    PoiModule,
    CategoriesModule,
    TagsModule,
    ItinerariesModule,
    ReviewsModule,
    FavoritesModule,
    FilesModule,
    AiModule,
  ],
  providers: [PrismaService],
})
export class AppModule {}