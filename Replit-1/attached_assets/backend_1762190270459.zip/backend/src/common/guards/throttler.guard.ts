import { Injectable, ExecutionContext } from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';

@Injectable()
export class CustomThrottlerGuard extends ThrottlerGuard {
  protected async getTracker(req: Record<string, any>): Promise<string> {
    // Use user ID if authenticated, otherwise fall back to IP
    const user = req.user;
    if (user?.id) {
      return `user:${user.id}`;
    }
    return req.ips?.length ? req.ips[0] : req.ip;
  }

  protected async getErrorMessage(): Promise<string> {
    return 'Rate limit exceeded. Please try again later.';
  }

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    
    // Skip throttling for health checks
    if (request.url === '/health' || request.url === '/api/health') {
      return true;
    }

    return super.canActivate(context);
  }
}