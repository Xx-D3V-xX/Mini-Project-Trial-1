import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  Logger,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Request, Response } from 'express';

@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger(LoggingInterceptor.name);

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const ctx = context.switchToHttp();
    const request = ctx.getRequest<Request>();
    const response = ctx.getResponse<Response>();

    const { method, url, ip } = request;
    const userAgent = request.get('User-Agent') || '';
    const reqId = request.headers['x-request-id'] as string || 
                  Math.random().toString(36).substring(2, 15);

    // Add request ID to response headers
    response.setHeader('x-request-id', reqId);

    const start = Date.now();

    return next.handle().pipe(
      tap(() => {
        const { statusCode } = response;
        const contentLength = response.get('content-length') || 0;
        const duration = Date.now() - start;

        // Redact sensitive information
        const sanitizedUrl = this.sanitizeUrl(url);

        this.logger.log(
          `${method} ${sanitizedUrl} ${statusCode} ${contentLength}b - ${duration}ms`,
          `${ip} ${userAgent} [${reqId}]`,
        );
      }),
    );
  }

  private sanitizeUrl(url: string): string {
    // Remove sensitive query parameters
    const sensitiveParams = ['password', 'token', 'secret', 'key'];
    let sanitizedUrl = url;

    sensitiveParams.forEach((param) => {
      const regex = new RegExp(`([?&]${param}=)[^&]*`, 'gi');
      sanitizedUrl = sanitizedUrl.replace(regex, `$1***`);
    });

    return sanitizedUrl;
  }
}