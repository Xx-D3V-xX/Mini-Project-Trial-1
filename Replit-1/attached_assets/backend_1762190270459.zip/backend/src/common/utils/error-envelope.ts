export interface ErrorEnvelope {
  error: string;
  message: string;
  code: number;
  reqId: string;
  timestamp: string;
}

export function createErrorEnvelope(
  error: string,
  message: string,
  code: number,
  reqId: string,
): ErrorEnvelope {
  return {
    error,
    message,
    code,
    reqId,
    timestamp: new Date().toISOString(),
  };
}

export function createValidationErrorEnvelope(
  validationErrors: any[],
  reqId: string,
): ErrorEnvelope {
  const messages = validationErrors
    .map((error) => {
      if (error.constraints) {
        return Object.values(error.constraints).join(', ');
      }
      return error.message || 'Validation error';
    })
    .filter(Boolean);

  return createErrorEnvelope(
    'ValidationError',
    `Validation failed: ${messages.join('; ')}`,
    400,
    reqId,
  );
}