import { Injectable, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() {
    await this.$connect();
  }

  async onModuleDestroy() {
    await this.$disconnect();
  }

  async cleanDb() {
    if (process.env.NODE_ENV === 'production') return;

    // Delete in order to avoid foreign key constraints
    await this.favorite.deleteMany();
    await this.review.deleteMany();
    await this.itineraryItem.deleteMany();
    await this.itinerary.deleteMany();
    await this.poiTag.deleteMany();
    await this.poiCategory.deleteMany();
    await this.poi.deleteMany();
    await this.tag.deleteMany();
    await this.category.deleteMany();
    await this.refreshToken.deleteMany();
    await this.oauthAccount.deleteMany();
    await this.user.deleteMany();
  }
}