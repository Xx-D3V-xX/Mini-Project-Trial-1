import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { PoiService } from './poi.service';

@ApiTags('poi')
@Controller('poi')
export class PoiController {
  constructor(private readonly poiService: PoiService) {}

  @Get()
  @ApiOperation({ summary: 'Get all POIs' })
  async findAll() {
    return { message: 'POI list endpoint - implementation pending', data: [] };
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get POI by ID' })
  async findOne(@Param('id') id: string) {
    return { message: 'POI detail endpoint - implementation pending', id };
  }

  @Post()
  @ApiOperation({ summary: 'Create new POI' })
  async create(@Body() createDto: any) {
    return { message: 'Create POI endpoint - implementation pending' };
  }
}