import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/services/prisma.service';

@Injectable()
export class PoiService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll() {
    // TODO: Implement POI listing
    return [];
  }

  async findOne(id: string) {
    // TODO: Implement POI detail
    return null;
  }

  async create(data: any) {
    // TODO: Implement POI creation
    return { message: 'POI creation not implemented yet' };
  }
}