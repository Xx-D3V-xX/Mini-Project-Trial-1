import { UserRole, PIILevel } from '@prisma/client';

// Role hierarchy levels
export const ROLE_HIERARCHY: Record<UserRole, number> = {
  guest: 0,
  registered: 1,
  contributor: 2,
  moderator: 6,
  admin: 7,
  superadmin: 8,
  analyst: 9,
} as const;

// Resource permissions
export enum Permission {
  // Basic user operations
  READ_SELF = 'read_self',
  WRITE_SELF = 'write_self',
  
  // Public content
  READ_PUBLIC = 'read_public',
  WRITE_PUBLIC = 'write_public',
  
  // User management
  READ_USERS = 'read_users',
  WRITE_USERS = 'write_users',
  
  // PII data access levels
  READ_PII_NONE = 'read_pii_none',
  READ_PII_INDIRECT = 'read_pii_indirect', 
  READ_PII_POTENTIAL = 'read_pii_potential',
  READ_PII_DIRECT = 'read_pii_direct',
  
  // Content moderation
  MODERATE_CONTENT = 'moderate_content',
  DELETE_CONTENT = 'delete_content',
  
  // System administration
  ADMIN_USERS = 'admin_users',
  ADMIN_SYSTEM = 'admin_system',
  
  // Audit and analytics
  READ_AUDIT_LOGS = 'read_audit_logs',
  READ_ANALYTICS = 'read_analytics',
  EXPORT_DATA = 'export_data',
}

// Role to permissions mapping
export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  guest: [
    Permission.READ_PUBLIC,
    Permission.READ_PII_NONE,
  ],
  
  registered: [
    Permission.READ_PUBLIC,
    Permission.WRITE_PUBLIC,
    Permission.READ_SELF,
    Permission.WRITE_SELF,
    Permission.READ_PII_NONE,
    Permission.READ_PII_INDIRECT, // Own data only
  ],
  
  contributor: [
    Permission.READ_PUBLIC,
    Permission.WRITE_PUBLIC,
    Permission.READ_SELF,
    Permission.WRITE_SELF,
    Permission.READ_PII_NONE,
    Permission.READ_PII_INDIRECT, // Own data only
  ],
  
  moderator: [
    Permission.READ_PUBLIC,
    Permission.WRITE_PUBLIC,
    Permission.READ_SELF,
    Permission.WRITE_SELF,
    Permission.MODERATE_CONTENT,
    Permission.DELETE_CONTENT,
    Permission.READ_PII_NONE,
    Permission.READ_PII_INDIRECT, // Own + moderated content
  ],
  
  admin: [
    Permission.READ_PUBLIC,
    Permission.WRITE_PUBLIC,
    Permission.READ_SELF,
    Permission.WRITE_SELF,
    Permission.READ_USERS,
    Permission.WRITE_USERS,
    Permission.MODERATE_CONTENT,
    Permission.DELETE_CONTENT,
    Permission.ADMIN_USERS,
    Permission.READ_PII_NONE,
    Permission.READ_PII_INDIRECT,
    Permission.READ_PII_POTENTIAL, // For user support
  ],
  
  superadmin: [
    Permission.READ_PUBLIC,
    Permission.WRITE_PUBLIC,
    Permission.READ_SELF,
    Permission.WRITE_SELF,
    Permission.READ_USERS,
    Permission.WRITE_USERS,
    Permission.MODERATE_CONTENT,
    Permission.DELETE_CONTENT,
    Permission.ADMIN_USERS,
    Permission.ADMIN_SYSTEM,
    Permission.READ_AUDIT_LOGS,
    Permission.EXPORT_DATA,
    Permission.READ_PII_NONE,
    Permission.READ_PII_INDIRECT,
    Permission.READ_PII_POTENTIAL,
    Permission.READ_PII_DIRECT, // Full PII access
  ],
  
  analyst: [
    Permission.READ_PUBLIC,
    Permission.READ_ANALYTICS,
    Permission.READ_PII_NONE, // Only aggregated, anonymized data
  ],
};

export class RBACService {
  // Make role hierarchy accessible as static property
  static ROLE_HIERARCHY = ROLE_HIERARCHY;

  /**
   * Check if a role has a specific permission
   */
  static hasPermission(role: UserRole, permission: Permission): boolean {
    return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
  }

  /**
   * Check if user role can access PII at a specific level
   */
  static canAccessPII(role: UserRole, piiLevel: PIILevel): boolean {
    switch (piiLevel) {
      case PIILevel.NONE:
        return this.hasPermission(role, Permission.READ_PII_NONE);
      case PIILevel.INDIRECT:
        return this.hasPermission(role, Permission.READ_PII_INDIRECT);
      case PIILevel.POTENTIAL:
        return this.hasPermission(role, Permission.READ_PII_POTENTIAL);
      case PIILevel.DIRECT:
        return this.hasPermission(role, Permission.READ_PII_DIRECT);
      default:
        return false;
    }
  }

  /**
   * Check if one role is higher in hierarchy than another
   */
  static isRoleHigherThan(role: UserRole, compareRole: UserRole): boolean {
    return ROLE_HIERARCHY[role] > ROLE_HIERARCHY[compareRole];
  }

  /**
   * Check if user can access another user's data
   */
  static canAccessUserData(
    currentUserRole: UserRole,
    currentUserId: string,
    targetUserId: string,
    piiLevel: PIILevel = PIILevel.NONE
  ): boolean {
    // Users can always access their own data
    if (currentUserId === targetUserId) {
      return true;
    }

    // Check if role has sufficient privileges for PII level
    if (!this.canAccessPII(currentUserRole, piiLevel)) {
      return false;
    }

    // Additional access rules by role
    switch (currentUserRole) {
      case 'guest':
        return false; // Guests can only access public data

      case 'registered':
      case 'contributor':
        // Can only access own data and public non-PII data
        return piiLevel === PIILevel.NONE;

      case 'moderator':
        // Can access indirect PII for moderation purposes
        return piiLevel <= PIILevel.INDIRECT;

      case 'admin':
        // Can access up to potential PII for user support
        return piiLevel <= PIILevel.POTENTIAL;

      case 'superadmin':
        // Full access to all data
        return true;

      case 'analyst':
        // Can only access anonymized/aggregated data
        return false;

      default:
        return false;
    }
  }

  /**
   * Get maximum PII level accessible by a role
   */
  static getMaxPIILevel(role: UserRole): PIILevel {
    if (this.hasPermission(role, Permission.READ_PII_DIRECT)) {
      return PIILevel.DIRECT;
    } else if (this.hasPermission(role, Permission.READ_PII_POTENTIAL)) {
      return PIILevel.POTENTIAL;
    } else if (this.hasPermission(role, Permission.READ_PII_INDIRECT)) {
      return PIILevel.INDIRECT;
    } else {
      return PIILevel.NONE;
    }
  }

  /**
   * Check if user can perform an action on a resource
   */
  static canPerformAction(
    userRole: UserRole,
    userId: string,
    action: Permission,
    resourceOwnerId?: string
  ): boolean {
    // Check basic permission
    if (!this.hasPermission(userRole, action)) {
      return false;
    }

    // For self-targeted actions, verify ownership
    if (action === Permission.READ_SELF || action === Permission.WRITE_SELF) {
      return userId === resourceOwnerId;
    }

    return true;
  }
}