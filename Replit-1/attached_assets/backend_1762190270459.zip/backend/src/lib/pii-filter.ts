import { UserRole, PIILevel } from '@prisma/client';
import { RBACService } from './rbac';

// PII field definitions with their sensitivity levels
export const PII_FIELD_MAPPINGS = {
  // Direct PII - personally identifiable
  id: PIILevel.DIRECT,
  email: PIILevel.DIRECT,
  phone: PIILevel.DIRECT,
  
  // Indirect PII - can be used to identify when combined
  displayName: PIILevel.INDIRECT,
  photoUrl: PIILevel.INDIRECT,
  provider: PIILevel.INDIRECT,
  lastLoginAt: PIILevel.INDIRECT,
  emailVerified: PIILevel.INDIRECT,
  interests: PIILevel.INDIRECT,
  budgetRange: PIILevel.INDIRECT,
  name: PIILevel.INDIRECT, // For favorites lists, etc.
  title: PIILevel.INDIRECT, // For itineraries
  startDate: PIILevel.INDIRECT,
  endDate: PIILevel.INDIRECT,
  handle: PIILevel.INDIRECT, // Pseudonymous but still identifying
  
  // Potential PII - may contain identifying information
  comment: PIILevel.POTENTIAL,
  reason: PIILevel.POTENTIAL,
  sampleText: PIILevel.POTENTIAL,
  body: PIILevel.POTENTIAL, // For local tips
  bio: PIILevel.POTENTIAL,
  
  // Sensitive metadata (not PII but sensitive)
  passwordHash: PIILevel.DIRECT,
  token: PIILevel.DIRECT,
  hashedKey: PIILevel.DIRECT,
  refreshToken: PIILevel.DIRECT,
  
  // Pseudonymous identifiers
  uidHashed: PIILevel.INDIRECT,
  sessionId: PIILevel.INDIRECT,
  ipAddress: PIILevel.INDIRECT,
  userAgent: PIILevel.INDIRECT,
  
  // Non-PII data
  description: PIILevel.NONE,
  address: PIILevel.NONE,
  city: PIILevel.NONE,
  latitude: PIILevel.NONE,
  longitude: PIILevel.NONE,
  rating: PIILevel.NONE,
  category: PIILevel.NONE,
  type: PIILevel.NONE,
  status: PIILevel.NONE,
  priority: PIILevel.NONE,
  language: PIILevel.NONE,
  timezone: PIILevel.NONE,
  currency: PIILevel.NONE,
  entryFee: PIILevel.NONE,
  overallRating: PIILevel.NONE,
  ratingCount: PIILevel.NONE,
  visibility: PIILevel.NONE,
  isActive: PIILevel.NONE,
  isPublic: PIILevel.NONE,
  isVerified: PIILevel.NONE,
  createdAt: PIILevel.NONE,
  updatedAt: PIILevel.NONE,
} as const;

export type PIIFieldName = keyof typeof PII_FIELD_MAPPINGS;

// Masking functions for different data types
export class PIIMaskingService {
  /**
   * Mask an email address
   */
  static maskEmail(email: string): string {
    const [user, domain] = email.split('@');
    if (!domain) return '***@***.***';
    
    const maskedUser = user.length > 2 
      ? user[0] + '*'.repeat(user.length - 2) + user[user.length - 1]
      : '*'.repeat(user.length);
    
    const [domainName, tld] = domain.split('.');
    const maskedDomain = domainName.length > 2
      ? domainName[0] + '*'.repeat(domainName.length - 2) + domainName[domainName.length - 1]
      : '*'.repeat(domainName.length);
    
    return `${maskedUser}@${maskedDomain}.${tld || '***'}`;
  }

  /**
   * Mask a phone number
   */
  static maskPhone(phone: string): string {
    if (phone.length < 4) return '*'.repeat(phone.length);
    return phone.slice(0, 2) + '*'.repeat(phone.length - 4) + phone.slice(-2);
  }

  /**
   * Mask a name or display name
   */
  static maskName(name: string): string {
    if (name.length < 2) return '*'.repeat(name.length);
    return name[0] + '*'.repeat(name.length - 1);
  }

  /**
   * Mask text content that may contain PII
   */
  static maskTextContent(content: string, maxVisible: number = 50): string {
    if (content.length <= maxVisible) {
      return '[REDACTED]';
    }
    return content.slice(0, maxVisible) + '... [REDACTED]';
  }

  /**
   * Mask any field based on its type and content
   */
  static maskField(fieldName: string, value: any): any {
    if (value === null || value === undefined) return value;

    switch (fieldName) {
      case 'email':
        return typeof value === 'string' ? this.maskEmail(value) : '[REDACTED_EMAIL]';
      
      case 'phone':
        return typeof value === 'string' ? this.maskPhone(value) : '[REDACTED_PHONE]';
      
      case 'displayName':
      case 'name':
        return typeof value === 'string' ? this.maskName(value) : '[REDACTED_NAME]';
      
      case 'comment':
      case 'reason':
      case 'sampleText':
      case 'body':
      case 'bio':
        return typeof value === 'string' ? this.maskTextContent(value) : '[REDACTED_TEXT]';
      
      case 'id':
        return '[REDACTED_ID]';
      
      case 'passwordHash':
      case 'token':
      case 'hashedKey':
        return '[REDACTED_SENSITIVE]';
      
      case 'interests':
        return Array.isArray(value) ? ['[REDACTED_INTERESTS]'] : '[REDACTED_INTERESTS]';
      
      case 'budgetRange':
        return { min: '[REDACTED]', max: '[REDACTED]' };
      
      case 'uidHashed':
        return '[REDACTED_UID]';
      
      case 'ipAddress':
        return typeof value === 'string' ? '***.***.***.' + value.split('.').pop() : '[REDACTED_IP]';
      
      default:
        return '[REDACTED]';
    }
  }
}

export class PIIFilterService {
  /**
   * Check if a field should be accessible based on user role and ownership
   */
  static canAccessField(
    userRole: UserRole,
    userId: string,
    targetUserId: string,
    fieldName: string
  ): boolean {
    const piiLevel = PII_FIELD_MAPPINGS[fieldName as PIIFieldName] || PIILevel.POTENTIAL;
    
    // Users always have access to their own data
    if (userId === targetUserId) {
      return true;
    }
    
    // Check if user role can access this PII level
    return RBACService.canAccessUserData(userRole, userId, targetUserId, piiLevel);
  }

  /**
   * Filter and mask object fields based on user permissions
   */
  static filterObject<T extends Record<string, any>>(
    obj: T,
    userRole: UserRole,
    userId: string,
    targetUserId: string
  ): Partial<T> {
    const filtered: Partial<T> = {};
    
    for (const [key, value] of Object.entries(obj)) {
      if (this.canAccessField(userRole, userId, targetUserId, key)) {
        filtered[key as keyof T] = value;
      } else {
        const piiLevel = PII_FIELD_MAPPINGS[key as PIIFieldName];
        
        // For non-PII fields, show the value
        if (piiLevel === PIILevel.NONE) {
          filtered[key as keyof T] = value;
        } else {
          // Mask PII fields that user cannot access
          filtered[key as keyof T] = PIIMaskingService.maskField(key, value) as T[keyof T];
        }
      }
    }
    
    return filtered;
  }

  /**
   * Filter array of objects
   */
  static filterObjectArray<T extends Record<string, any>>(
    objects: T[],
    userRole: UserRole,
    userId: string,
    getTargetUserId: (obj: T) => string
  ): Partial<T>[] {
    return objects.map(obj => 
      this.filterObject(obj, userRole, userId, getTargetUserId(obj))
    );
  }

  /**
   * Get Prisma select object that excludes sensitive fields user cannot access
   */
  static getPrismaSelect(
    userRole: UserRole,
    userId: string,
    targetUserId: string,
    baseSelect: Record<string, any> = {}
  ): Record<string, any> {
    const select: Record<string, any> = { ...baseSelect };
    
    // Add accessible fields
    for (const [fieldName, piiLevel] of Object.entries(PII_FIELD_MAPPINGS)) {
      if (this.canAccessField(userRole, userId, targetUserId, fieldName)) {
        select[fieldName] = true;
      } else if (piiLevel === PIILevel.NONE) {
        // Always include non-PII fields
        select[fieldName] = true;
      }
      // Exclude other PII fields to avoid leakage
    }
    
    return select;
  }

  /**
   * Create a privacy-aware Prisma where clause for user data access
   */
  static createUserAccessWhere(
    userRole: UserRole,
    userId: string,
    additionalWhere: any = {}
  ): any {
    const baseWhere = { ...additionalWhere };
    
    // Regular users can only see their own private data
    if (userRole === 'registered' || userRole === 'contributor') {
      return {
        ...baseWhere,
        userId: userId, // Restrict to own data
      };
    }
    
    // Moderators and above can see broader data, but filtering happens at field level
    return baseWhere;
  }

  /**
   * Get visibility filter for itineraries based on user role
   */
  static getItineraryVisibilityFilter(userRole: UserRole, userId: string): any {
    switch (userRole) {
      case 'guest':
        return { visibility: 'public_demo' };
      
      case 'registered':
      case 'contributor':
        return {
          OR: [
            { visibility: 'public_demo' },
            { visibility: 'shared' },
            { userId: userId, visibility: 'private' }, // Own private itineraries
          ],
        };
      
      case 'moderator':
      case 'admin':
      case 'superadmin':
        // Can see all itineraries, but PII filtering still applies at field level
        return {};
      
      case 'analyst':
        // Only public demo data for analytics
        return { visibility: 'public_demo' };
      
      default:
        return { visibility: 'public_demo' };
    }
  }
}