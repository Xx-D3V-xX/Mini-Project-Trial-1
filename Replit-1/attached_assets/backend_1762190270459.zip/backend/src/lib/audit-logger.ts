import { UserRole, PIILevel } from '@prisma/client';
import { PrismaClient } from '@prisma/client';
import { Request } from 'express';

const prisma = new PrismaClient();

export enum AuditAction {
  // Authentication events
  LOGIN = 'login',
  LOGOUT = 'logout',
  PASSWORD_RESET = 'password_reset',
  
  // Data access events
  DATA_READ = 'data_read',
  DATA_WRITE = 'data_write',
  DATA_DELETE = 'data_delete',
  
  // PII-specific events
  PII_ACCESS = 'pii_access',
  PII_EXPORT = 'pii_export',
  PII_MASK_BYPASS = 'pii_mask_bypass',
  
  // Admin actions
  USER_ROLE_CHANGE = 'user_role_change',
  USER_SUSPEND = 'user_suspend',
  USER_DELETE = 'user_delete',
  
  // System events
  SYSTEM_CONFIG = 'system_config',
  BACKUP_CREATED = 'backup_created',
  MAINTENANCE_MODE = 'maintenance_mode',
  
  // Content moderation
  CONTENT_MODERATE = 'content_moderate',
  CONTENT_DELETE = 'content_delete',
  USER_REPORT = 'user_report',
}

export interface AuditContext {
  adminId: string;
  adminRole: UserRole;
  action: AuditAction;
  targetType?: string;
  targetId?: string;
  details?: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
  purpose?: string; // Required for PII access
  expiresAt?: Date; // For time-boxed access
  request?: Request;
}

export interface PIIAccessContext extends AuditContext {
  targetUserId: string;
  piiLevel: PIILevel;
  fieldsAccessed: string[];
  purpose: string; // Mandatory for PII access
}

export class AuditLogger {
  /**
   * Log a general admin action
   */
  static async logAction(context: AuditContext): Promise<void> {
    try {
      const { request, ...logData } = context;
      
      // Extract IP and user agent from request if not provided
      const ipAddress = context.ipAddress || 
        request?.ip || 
        request?.socket?.remoteAddress || 
        'unknown';
      
      const userAgent = context.userAgent || 
        request?.get('User-Agent') || 
        'unknown';

      // Filter sensitive data from details
      const sanitizedDetails = this.sanitizeDetails(logData.details || {});

      await prisma.adminAuditLog.create({
        data: {
          adminId: context.adminId,
          action: context.action,
          targetType: context.targetType,
          targetId: context.targetId,
          details: sanitizedDetails,
          ipAddress,
          userAgent,
          purpose: context.purpose,
          expiresAt: context.expiresAt,
        },
      });
    } catch (error) {
      console.error('Failed to log audit event:', error);
      // Don't throw - audit logging should not break the main flow
    }
  }

  /**
   * Log PII data access with enhanced details
   */
  static async logPIIAccess(context: PIIAccessContext): Promise<void> {
    const auditContext: AuditContext = {
      ...context,
      action: AuditAction.PII_ACCESS,
      targetType: 'user',
      targetId: context.targetUserId,
      details: {
        piiLevel: context.piiLevel,
        fieldsAccessed: context.fieldsAccessed,
        originalAction: context.action,
      },
    };

    await this.logAction(auditContext);
  }

  /**
   * Log data export events
   */
  static async logDataExport(
    adminId: string,
    adminRole: UserRole,
    exportType: string,
    targetUserId?: string,
    recordCount?: number,
    request?: Request
  ): Promise<void> {
    await this.logAction({
      adminId,
      adminRole,
      action: AuditAction.PII_EXPORT,
      targetType: exportType,
      targetId: targetUserId,
      details: {
        exportType,
        recordCount,
        timestamp: new Date().toISOString(),
      },
      purpose: 'Data export requested by admin',
      request,
    });
  }

  /**
   * Log role changes
   */
  static async logRoleChange(
    adminId: string,
    adminRole: UserRole,
    targetUserId: string,
    oldRole: UserRole,
    newRole: UserRole,
    reason?: string,
    request?: Request
  ): Promise<void> {
    await this.logAction({
      adminId,
      adminRole,
      action: AuditAction.USER_ROLE_CHANGE,
      targetType: 'user',
      targetId: targetUserId,
      details: {
        oldRole,
        newRole,
        reason,
      },
      purpose: reason || 'Role change',
      request,
    });
  }

  /**
   * Log user authentication events
   */
  static async logAuth(
    userId: string,
    action: AuditAction.LOGIN | AuditAction.LOGOUT,
    request?: Request,
    additionalDetails?: Record<string, any>
  ): Promise<void> {
    await this.logAction({
      adminId: userId,
      adminRole: 'registered', // Will be updated with actual role
      action,
      details: additionalDetails,
      request,
    });
  }

  /**
   * Get audit logs with filtering (SuperAdmin only)
   */
  static async getAuditLogs(
    requestingUserRole: UserRole,
    filters: {
      adminId?: string;
      action?: AuditAction;
      targetType?: string;
      targetId?: string;
      startDate?: Date;
      endDate?: Date;
      limit?: number;
      offset?: number;
    } = {}
  ) {
    // Only SuperAdmins can view audit logs
    if (requestingUserRole !== 'superadmin') {
      throw new Error('Unauthorized: Audit logs are only accessible to SuperAdmins');
    }

    const {
      adminId,
      action,
      targetType,
      targetId,
      startDate,
      endDate,
      limit = 100,
      offset = 0,
    } = filters;

    const where: any = {};

    if (adminId) where.adminId = adminId;
    if (action) where.action = action;
    if (targetType) where.targetType = targetType;
    if (targetId) where.targetId = targetId;
    
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = startDate;
      if (endDate) where.createdAt.lte = endDate;
    }

    return await prisma.adminAuditLog.findMany({
      where,
      include: {
        admin: {
          select: {
            email: true,
            role: true,
            profile: {
              select: {
                displayName: true,
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
    });
  }

  /**
   * Get recent PII access logs for a specific user (SuperAdmin only)
   */
  static async getUserPIIAccess(
    requestingUserRole: UserRole,
    targetUserId: string,
    days: number = 30
  ) {
    if (requestingUserRole !== 'superadmin') {
      throw new Error('Unauthorized: PII access logs are only accessible to SuperAdmins');
    }

    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    return await prisma.adminAuditLog.findMany({
      where: {
        action: AuditAction.PII_ACCESS,
        targetId: targetUserId,
        createdAt: {
          gte: startDate,
        },
      },
      include: {
        admin: {
          select: {
            email: true,
            role: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Check for suspicious PII access patterns
   */
  static async detectSuspiciousAccess(
    requestingUserRole: UserRole,
    timeWindowHours: number = 1,
    accessThreshold: number = 10
  ) {
    if (requestingUserRole !== 'superadmin') {
      throw new Error('Unauthorized');
    }

    const startTime = new Date();
    startTime.setHours(startTime.getHours() - timeWindowHours);

    // Find admins with excessive PII access in the time window
    const suspiciousActivity = await prisma.adminAuditLog.groupBy({
      by: ['adminId'],
      where: {
        action: AuditAction.PII_ACCESS,
        createdAt: {
          gte: startTime,
        },
      },
      _count: {
        id: true,
      },
      having: {
        id: {
          _count: {
            gte: accessThreshold,
          },
        },
      },
    });

    return suspiciousActivity;
  }

  /**
   * Sanitize details object to remove sensitive data from audit logs
   */
  private static sanitizeDetails(details: Record<string, any>): Record<string, any> {
    const sanitized = { ...details };
    
    // Remove sensitive fields that shouldn't be stored in audit logs
    const sensitiveFields = ['password', 'passwordHash', 'token', 'refreshToken', 'hashedKey'];
    
    for (const field of sensitiveFields) {
      if (sanitized[field]) {
        sanitized[field] = '[REDACTED]';
      }
    }

    // Truncate long text fields
    for (const [key, value] of Object.entries(sanitized)) {
      if (typeof value === 'string' && value.length > 1000) {
        sanitized[key] = value.substring(0, 1000) + '... [TRUNCATED]';
      }
    }

    return sanitized;
  }

  /**
   * Create a middleware for automatic audit logging
   */
  static createMiddleware() {
    return (req: Request, res: any, next: any) => {
      // Store original end function
      const originalEnd = res.end;
      
      // Override end function to log after response
      res.end = function(chunk?: any, encoding?: any) {
        // Call original end
        originalEnd.call(this, chunk, encoding);
        
        // Log the request if it's from an admin user
        if (req.user && ['admin', 'superadmin', 'moderator'].includes(req.user.role)) {
          const method = req.method;
          const path = req.path;
          const statusCode = res.statusCode;
          
          // Determine action based on method and path
          let action = AuditAction.DATA_READ;
          if (method === 'POST' || method === 'PUT' || method === 'PATCH') {
            action = AuditAction.DATA_WRITE;
          } else if (method === 'DELETE') {
            action = AuditAction.DATA_DELETE;
          }
          
          // Log the action (async, don't wait)
          AuditLogger.logAction({
            adminId: req.user.id,
            adminRole: req.user.role,
            action,
            details: {
              method,
              path,
              statusCode,
              params: req.params,
              query: req.query,
            },
            request: req,
          }).catch(error => {
            console.error('Failed to log admin action:', error);
          });
        }
      };
      
      next();
    };
  }
}
