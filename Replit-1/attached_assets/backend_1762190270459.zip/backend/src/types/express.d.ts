import { UserRole, PIILevel } from '@prisma/client';

declare global {
  namespace Express {
    interface User {
      id: string;
      role: UserRole;
      email: string;
      isActive?: boolean;
    }
    
    interface Request {
      user?: User;
      privacy?: {
        requiresPIIAccess: boolean;
        targetUserId?: string;
        fieldsAccessed?: string[];
        piiLevel?: PIILevel;
      };
    }
  }
}

export {};
