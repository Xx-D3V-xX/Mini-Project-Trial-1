# MumbAI Trails Backend Setup

This document provides setup instructions for the PostgreSQL-only MVP backend with Express, Socket.IO, and JWT authentication.

## Prerequisites

- Node.js 18+ and npm
- PostgreSQL 14+ with `pgcrypto` and `citext` extensions
- Windows PowerShell (for setup commands)

## Installation Commands

Run these commands in PowerShell from the backend directory:

```powershell
# Install dependencies
npm i express zod bcrypt jsonwebtoken cors socket.io @prisma/client
npm i -D typescript ts-node-dev prisma @types/express @types/jsonwebtoken @types/cors @types/node @types/bcrypt

# Initialize Prisma (already done)
# npx prisma init

# Generate Prisma client and run migrations
npx prisma migrate dev --name chat_mvp
npx prisma generate

# Start development server
npm run dev
```

## Environment Setup

1. Copy `.env.example` to `.env`
2. Update the database URL and secrets:

```env
DATABASE_URL="postgresql://username:password@localhost:5432/mumbai_trails"
ACCESS_TOKEN_SECRET="your-super-secret-access-token-key-here"
REFRESH_TOKEN_SECRET="your-super-secret-refresh-token-key-here"
PORT=3000
NODE_ENV=development
ALLOWED_ORIGINS="http://localhost:3000,http://localhost:5173"
```

## Database Setup

1. Create the PostgreSQL database:
```sql
CREATE DATABASE mumbai_trails;
```

2. Run the DDL manually (optional, migration handles this):
```powershell
# Connect to PostgreSQL and run 000_chat_mvp.sql
psql -U username -d mumbai_trails -f 000_chat_mvp.sql
```

## Testing the API

### 1. Signup
```powershell
curl.exe -X POST http://localhost:3000/auth/signup -H "Content-Type: application/json" -d '{\"email\":\"test@example.com\",\"password\":\"password123\",\"displayName\":\"Test User\"}'
```

### 2. Login (capture tokens)
```powershell
curl.exe -X POST http://localhost:3000/auth/login -H "Content-Type: application/json" -d '{\"email\":\"test@example.com\",\"password\":\"password123\"}'
```

### 3. Create session (replace ACCESS_TOKEN)
```powershell
curl.exe -X POST http://localhost:3000/chat/sessions -H "Content-Type: application/json" -H "Authorization: Bearer ACCESS_TOKEN" -d '{\"modelConfig\":{\"model\":\"gpt-4\"},\"tags\":[\"general\"]}'
```

### 4. Post message (replace ACCESS_TOKEN and SESSION_ID)
```powershell
curl.exe -X POST http://localhost:3000/chat/messages -H "Content-Type: application/json" -H "Authorization: Bearer ACCESS_TOKEN" -d '{\"sessionId\":\"SESSION_ID\",\"role\":\"user\",\"content\":\"Hello, how are you?\",\"tokensIn\":5}'
```

### 5. Post feedback (replace ACCESS_TOKEN and MESSAGE_ID)
```powershell
curl.exe -X POST http://localhost:3000/chat/feedback -H "Content-Type: application/json" -H "Authorization: Bearer ACCESS_TOKEN" -d '{\"messageId\":\"MESSAGE_ID\",\"rating\":1,\"reasonTag\":\"helpful\",\"notes\":\"Good response\"}'
```

### 6. List messages (replace ACCESS_TOKEN and SESSION_ID)
```powershell
curl.exe -X GET "http://localhost:3000/chat/sessions/SESSION_ID/messages" -H "Authorization: Bearer ACCESS_TOKEN"
```

### 7. Refresh token (replace REFRESH_TOKEN)
```powershell
curl.exe -X POST http://localhost:3000/auth/refresh -H "Content-Type: application/json" -d '{\"refreshToken\":\"REFRESH_TOKEN\"}'
```

## WebSocket Testing

Connect to `ws://localhost:3000/chat` with authentication token in query params or auth header:

```javascript
const socket = io('ws://localhost:3000/chat', {
  auth: { token: 'your-access-token' }
});

// Join a session
socket.emit('chat:join', { sessionId: 'your-session-id' });

// Send a message
socket.emit('chat:message', {
  sessionId: 'your-session-id',
  role: 'user',
  content: 'Hello via WebSocket!'
});

// Send typing indicator
socket.emit('chat:typing', {
  sessionId: 'your-session-id',
  isTyping: true
});

// Submit feedback
socket.emit('chat:feedback', {
  messageId: 'your-message-id',
  rating: 1,
  reasonTag: 'helpful'
});
```

## Project Structure

```
backend/
├── src/
│   ├── db/
│   │   └── prisma.ts          # Prisma client singleton
│   ├── lib/
│   │   └── jwt.ts            # JWT utilities and password hashing
│   ├── middleware/
│   │   └── auth.ts           # Authentication middleware
│   ├── routes/
│   │   ├── auth.ts           # Authentication endpoints
│   │   └── chat.ts           # Chat REST API endpoints
│   ├── ws.ts                 # WebSocket server setup
│   └── server.ts             # Main Express server
├── prisma/
│   └── schema.prisma         # Prisma schema with snake_case mapping
├── 000_chat_mvp.sql         # PostgreSQL DDL
├── RLS_HARDENING.md         # Security hardening documentation
└── package.json             # Dependencies and scripts
```

## API Endpoints

### Authentication
- `POST /auth/signup` - Create new user account
- `POST /auth/login` - User login
- `POST /auth/refresh` - Rotate refresh tokens

### Chat
- `POST /chat/sessions` - Create chat session
- `GET /chat/sessions/:id/messages` - List session messages
- `POST /chat/messages` - Send message
- `POST /chat/feedback` - Submit message feedback

### WebSocket Events
- `chat:join` - Join session room
- `chat:message` - Send/receive messages
- `chat:typing` - Typing indicators
- `chat:feedback` - Submit feedback

## Development

```powershell
# Start development server
npm run dev

# Run Prisma Studio (database GUI)
npm run prisma:studio

# Generate Prisma client after schema changes
npm run prisma:generate

# Reset database (destructive)
npx prisma migrate reset
```

## Production Deployment

1. Build the TypeScript code: `npm run build`
2. Set production environment variables
3. Run database migrations: `npx prisma migrate deploy`
4. Start the server: `npm start`

For enhanced security, see `RLS_HARDENING.md` for row-level security policies.