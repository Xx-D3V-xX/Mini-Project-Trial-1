# Row-Level Security (RLS) Hardening

This document provides SQL policies and Prisma patterns for implementing row-level security as a defense-in-depth layer.

**Note**: RLS is optional for the MVP but recommended for production hardening. App-level authorization still runs in middleware, and RLS provides an additional security layer.

## SQL Policies

```sql
-- Enable RLS on user-owned tables
ALTER TABLE chat_session ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_message ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_event_log ENABLE ROW LEVEL SECURITY;

-- Helper function to set app user context
CREATE OR REPLACE FUNCTION set_app_user(user_uuid TEXT)
RETURNS void AS $$
BEGIN
    PERFORM set_config('app.user_id', user_uuid, true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Policies for chat_session
CREATE POLICY chat_session_owner_policy ON chat_session
    FOR ALL TO PUBLIC
    USING (user_id::text = current_setting('app.user_id', true));

-- Policies for chat_message (via session ownership)
CREATE POLICY chat_message_owner_policy ON chat_message
    FOR ALL TO PUBLIC
    USING (
        user_id::text = current_setting('app.user_id', true) OR
        EXISTS (
            SELECT 1 FROM chat_session cs 
            WHERE cs.id = chat_message.session_id 
            AND cs.user_id::text = current_setting('app.user_id', true)
        )
    );

-- Policies for chat_feedback
CREATE POLICY chat_feedback_owner_policy ON chat_feedback
    FOR ALL TO PUBLIC
    USING (
        user_id::text = current_setting('app.user_id', true) OR
        EXISTS (
            SELECT 1 FROM chat_message cm
            JOIN chat_session cs ON cm.session_id = cs.id
            WHERE cm.id = chat_feedback.message_id
            AND cs.user_id::text = current_setting('app.user_id', true)
        )
    );

-- Policies for chat_event_log
CREATE POLICY chat_event_log_owner_policy ON chat_event_log
    FOR ALL TO PUBLIC
    USING (
        EXISTS (
            SELECT 1 FROM chat_session cs 
            WHERE cs.id = chat_event_log.session_id 
            AND cs.user_id::text = current_setting('app.user_id', true)
        )
    );
```

## Prisma RLS Pattern

Create a helper function in your service layer:

```typescript
// Example usage in routes/middleware
async function withRLS<T>(userId: string, operation: (tx: any) => Promise<T>): Promise<T> {
  return await prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT set_config('app.user_id', ${userId}, true)`;
    return await operation(tx);
  });
}

// Usage example in routes
const messages = await withRLS(req.userId!, async (tx) => {
  return await tx.chatMessage.findMany({
    where: { sessionId },
    orderBy: { createdAt: 'asc' }
  });
});
```

## Implementation Steps

1. **Run the SQL policies** on your PostgreSQL database after running the main schema
2. **Update your route handlers** to use the `withRLS` pattern for sensitive queries
3. **Test the policies** by attempting to access data from different users
4. **Monitor query performance** as RLS policies add query complexity

## Security Benefits

- **Defense in Depth**: Even if application logic fails, database enforces data isolation
- **Audit Compliance**: Database-level access controls for sensitive data
- **Query Transparency**: All queries automatically filtered by user context
- **Zero Trust**: Database doesn't trust application-level user validation

## Performance Considerations

- RLS policies add WHERE clauses to every query
- Use appropriate indexes to support policy conditions
- Consider policy complexity vs. performance trade-offs
- Monitor slow query logs after implementation

## ML Feedback Export Query

For nightly ML training data export:

```sql
SELECT 
    cm.session_id,
    cm.id as message_id,
    CASE 
        WHEN cm.user_id IS NOT NULL THEN encode(digest(cm.user_id::text, 'sha256'), 'hex')
        ELSE NULL 
    END as user_id_hash,
    cm.role,
    cm.content,
    cm.tokens_in,
    cm.tokens_out,
    cm.latency_ms,
    cm.created_at,
    cf.rating as feedback_rating,
    cf.reason_tag as feedback_reason_tag,
    cf.notes as feedback_notes,
    cs.model_config,
    cm.meta as message_meta,
    cs.client_meta,
    cs.tags
FROM chat_message cm
JOIN chat_session cs ON cm.session_id = cs.id
LEFT JOIN LATERAL (
    SELECT rating, reason_tag, notes
    FROM chat_feedback 
    WHERE message_id = cm.id 
    ORDER BY created_at DESC 
    LIMIT 1
) cf ON true
WHERE cm.created_at >= CURRENT_DATE - INTERVAL '1 day'
  AND cm.created_at < CURRENT_DATE
ORDER BY cm.session_id, cm.created_at;
```

This query provides denormalized training data with:
- Hashed user IDs for privacy
- Latest feedback per message
- All relevant metadata for ML training
- Time-bounded for daily exports