# MumbAI Trails - Comprehensive Privacy & RBAC System

## Overview

This system implements comprehensive PII (Personally Identifiable Information) protection and Role-Based Access Control (RBAC) for the MumbAI Trails platform. It ensures that sensitive user data is protected through field-level access control, automatic data masking, and comprehensive audit logging.

## Key Components

### 1. Role Hierarchy

The system implements a hierarchical role structure with increasing privilege levels:

- **Guest (Level 0)**: Unauthenticated users - access to public data only
- **Registered (Level 1)**: Basic authenticated users - access to own data + public data
- **Contributor (Level 2)**: Local contributors - same as registered + content contribution
- **Moderator (Level 6)**: Content moderators - can moderate and access indirect PII
- **Admin (Level 7)**: Platform administrators - user management + potential PII access  
- **SuperAdmin (Level 8)**: System administrators - full access + audit logs
- **Analyst (Level 9)**: Data analysts - aggregated data only, no individual PII

### 2. PII Classification Levels

All data fields are classified by sensitivity:

- **NONE**: Non-sensitive public data (coordinates, ratings, categories)
- **INDIRECT**: Can identify when combined (display names, preferences, dates)
- **POTENTIAL**: May contain identifying info (comments, reviews, user content)
- **DIRECT**: Directly identifies individuals (email, phone, IDs)

### 3. Core Services

#### RBACService (`src/lib/rbac.ts`)
- Permission checking and role hierarchy validation
- User data access authorization
- Role comparison and privilege escalation checks

#### PIIFilterService (`src/lib/pii-filter.ts`)
- Field-level PII classification and access control
- Automatic data masking for unauthorized access
- Prisma query filtering for privacy compliance

#### AuditLogger (`src/lib/audit-logger.ts`)
- Comprehensive logging of all PII data access
- Admin action tracking and suspicious activity detection
- GDPR-compliant audit trails

#### Privacy Middleware (`src/middleware/privacy.ts`)
- Automatic request/response filtering
- Integrated authentication, authorization, and audit logging
- Express middleware for seamless integration

## Usage Examples

### Basic Route Protection

```typescript
import { createPrivacyMiddleware, requireRole } from '../middleware/privacy';
import { Permission } from '../lib/rbac';

// Protect admin-only endpoint
app.use('/admin', createPrivacyMiddleware({
  minimumRole: 'admin',
  requiredPermission: Permission.ADMIN_USERS,
  logAccess: true
}));

// Protect user data access
app.use('/users/:userId', requireUserAccess({
  maxPIILevel: PIILevel.INDIRECT
}));
```

### Manual PII Filtering

```typescript
import { PIIFilterService } from '../lib/pii-filter';
import { AuditLogger, AuditAction } from '../lib/audit-logger';

// Filter user data based on requesting user's permissions
const filteredUser = PIIFilterService.filterObject(
  userData, 
  req.user.role, 
  req.user.id, 
  targetUserId
);

// Log PII access for audit purposes
await AuditLogger.logPIIAccess({
  adminId: req.user.id,
  adminRole: req.user.role,
  action: AuditAction.PII_ACCESS,
  targetUserId: targetUserId,
  piiLevel: PIILevel.DIRECT,
  fieldsAccessed: ['email', 'phone'],
  purpose: 'User profile update',
  request: req
});
```

### Role-Based Data Queries

```typescript
import { PIIFilterService } from '../lib/pii-filter';

// Get privacy-compliant Prisma select
const select = PIIFilterService.getPrismaSelect(
  req.user.role,
  req.user.id,
  targetUserId
);

// Create privacy-aware where clause
const where = PIIFilterService.createUserAccessWhere(
  req.user.role,
  req.user.id,
  { status: 'active' }
);

// Query with automatic privacy filtering
const users = await prisma.user.findMany({
  where,
  select,
});
```

## Database Schema

### Privacy-Focused Models

The system includes new models for enhanced privacy:

- **UserProfile**: Extended user information with PII annotations
- **UserPreferences**: User preferences and settings
- **AdminAuditLog**: Comprehensive audit logging
- **RoleBinding**: Role assignment tracking
- **LocalContributorProfile**: Verified local contributor data
- **Report**: Content reporting system

### PII Field Annotations

All model fields are annotated with their PII level:

```prisma
model User {
  id              String    @id // PII: Direct
  email           String    @unique // PII: Direct  
  displayName     String?   // PII: Indirect
  lastLoginAt     DateTime? // PII: Indirect
  preferences     Json?     // PII: Indirect
  bio             String?   // PII: Potential
}
```

## Audit & Compliance

### Automatic Audit Logging

All PII access is automatically logged with:
- User performing the action
- Target user/data accessed  
- PII level accessed
- Fields accessed
- Purpose and context
- IP address and user agent
- Timestamp

### GDPR Compliance Features

- **Right to Access**: Users can see who accessed their data
- **Right to Portability**: Data export with full audit trail
- **Right to Rectification**: All data changes are logged
- **Right to Erasure**: Deletion tracking and verification
- **Data Protection Impact**: Automatic risk assessment

### Suspicious Activity Detection

```typescript
// Detect excessive PII access
const suspicious = await AuditLogger.detectSuspiciousAccess(
  'superadmin', // Only SuperAdmins can run this
  1, // Time window in hours
  10 // Access threshold
);
```

## Security Features

### Automatic Data Masking

- Email: `j***n@ex***e.com`
- Phone: `98******45`
- Names: `J*****`
- Content: `[REDACTED]` or truncated with `... [REDACTED]`

### Access Control Matrix

| Role | Public Data | Own PII | Others' Indirect | Others' Direct | Audit Logs |
|------|-------------|---------|------------------|----------------|------------|
| Guest | ✓ | - | - | - | - |
| Registered | ✓ | ✓ | - | - | - |
| Contributor | ✓ | ✓ | - | - | - |
| Moderator | ✓ | ✓ | ✓ | - | - |
| Admin | ✓ | ✓ | ✓ | Limited | - |
| SuperAdmin | ✓ | ✓ | ✓ | ✓ | ✓ |
| Analyst | Aggregated | - | - | - | - |

### Time-Boxed Access

For sensitive operations, access can be time-limited:

```typescript
await AuditLogger.logAction({
  // ... action details
  purpose: 'Emergency user support',
  expiresAt: new Date(Date.now() + 60 * 60 * 1000) // 1 hour
});
```

## Integration Guide

### 1. Apply Middleware

```typescript
import { createPrivacyMiddleware, privacyErrorHandler } from '../middleware/privacy';

// Apply to all routes
app.use(createPrivacyMiddleware());

// Add error handler
app.use(privacyErrorHandler);
```

### 2. Use Type Extensions

The system extends Express types for seamless integration:

```typescript
// req.user is automatically typed with role and privacy context
app.get('/protected', (req, res) => {
  if (req.user?.role === 'admin') {
    // TypeScript knows user has role property
  }
  
  if (req.privacy?.requiresPIIAccess) {
    // Privacy context is available
  }
});
```

### 3. Custom Permission Checks

```typescript
import { RBACService, Permission } from '../lib/rbac';

// Check specific permissions
if (RBACService.hasPermission(user.role, Permission.DELETE_CONTENT)) {
  // User can delete content
}

// Check data access permissions
if (RBACService.canAccessUserData(currentRole, currentId, targetId, PIILevel.DIRECT)) {
  // Can access direct PII
}
```

## Configuration

### Environment Variables

```bash
# Audit log retention (days)
AUDIT_LOG_RETENTION_DAYS=90

# PII access rate limiting
PII_ACCESS_RATE_LIMIT=100

# SuperAdmin notifications
SUPERADMIN_ALERT_EMAIL=security@mumbaitrails.com
```

### Customization

Extend the system by:
1. Adding new permissions to `Permission` enum
2. Updating `ROLE_PERMISSIONS` mapping  
3. Adding new PII field classifications
4. Implementing custom audit actions

## Monitoring & Alerts

### Key Metrics to Monitor

- PII access frequency by role
- Failed authorization attempts
- Suspicious access patterns
- Data export requests
- Role elevation events

### Alert Conditions

- Excessive PII access (>10 records/hour)
- Direct PII access by non-SuperAdmins
- Failed SuperAdmin login attempts
- Bulk data exports
- Off-hours administrative actions

## Best Practices

1. **Always use the middleware** for automatic protection
2. **Log with purpose** - include business justification for PII access
3. **Minimize data exposure** - only request fields you need
4. **Regular audits** - review access patterns monthly
5. **Time-box sensitive access** - limit duration for emergency access
6. **Educate users** - train team on privacy implications

## Compliance Checklist

- [ ] All PII fields classified and annotated
- [ ] Audit logging enabled on all endpoints
- [ ] Role-based access controls implemented
- [ ] Data masking configured correctly
- [ ] Suspicious activity detection active
- [ ] Regular audit log reviews scheduled
- [ ] Privacy impact assessments completed
- [ ] Staff training on privacy system completed

This system ensures MumbAI Trails meets the highest standards for data privacy and security while maintaining usability for legitimate business purposes.