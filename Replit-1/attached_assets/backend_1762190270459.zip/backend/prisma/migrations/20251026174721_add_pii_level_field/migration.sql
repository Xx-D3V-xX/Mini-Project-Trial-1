-- AlterTable
ALTER TABLE "admin_audit_logs" ADD COLUMN     "pii_level" "pii_level" NOT NULL DEFAULT 'NONE';
